import { Pool } from "pg";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

export const db = {
  query: (text: string, params?: unknown[]) => pool.query(text, params),
};

export async function getSetting(key: string): Promise<string | null> {
  const r = await db.query("SELECT value FROM admin_settings WHERE key=$1", [key]);
  return r.rows[0]?.value ?? null;
}

export async function getSettings(): Promise<Record<string, string>> {
  const r = await db.query("SELECT key, value FROM admin_settings");
  return Object.fromEntries(r.rows.map((row: { key: string; value: string }) => [row.key, row.value]));
}

export async function setSetting(key: string, value: string): Promise<void> {
  await db.query(
    "INSERT INTO admin_settings (key, value, updated_at) VALUES ($1,$2,NOW()) ON CONFLICT (key) DO UPDATE SET value=$2, updated_at=NOW()",
    [key, value]
  );
}

export async function getAdminPin(): Promise<string> {
  const r = await db.query("SELECT pin FROM admin_auth ORDER BY id LIMIT 1");
  return r.rows[0]?.pin ?? "1234";
}

export async function setAdminPin(pin: string): Promise<void> {
  const r = await db.query("UPDATE admin_auth SET pin=$1, updated_at=NOW()", [pin]);
  if ((r as { rowCount: number }).rowCount === 0) {
    await db.query("INSERT INTO admin_auth (pin) VALUES ($1)", [pin]);
  }
}

export async function ensureAdminAuth(): Promise<void> {
  const r = await db.query("SELECT id FROM admin_auth LIMIT 1");
  if (r.rows.length === 0) {
    await db.query("INSERT INTO admin_auth (pin) VALUES ('1234')");
  }
}

export async function ensureDbConstraints(): Promise<void> {
  await db.query(`
    DO $$ BEGIN
      IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'user_tasks_user_task_unique'
      ) THEN
        ALTER TABLE user_tasks ADD CONSTRAINT user_tasks_user_task_unique UNIQUE (user_id, task_id);
      END IF;
    END $$;
  `);
  await db.query(`
    ALTER TABLE support_messages
      ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'ai_answered',
      ADD COLUMN IF NOT EXISTS assigned_to VARCHAR(255),
      ADD COLUMN IF NOT EXISTS escalated_at TIMESTAMP,
      ADD COLUMN IF NOT EXISTS resolved_at TIMESTAMP;
  `);
  await db.query(`
    ALTER TABLE password_resets
      ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'pending',
      ADD COLUMN IF NOT EXISTS approved_at TIMESTAMP,
      ADD COLUMN IF NOT EXISTS used_at TIMESTAMP;
  `);
  await db.query(`
    CREATE TABLE IF NOT EXISTS task_views (
      id SERIAL PRIMARY KEY,
      user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
      task_id INTEGER REFERENCES tasks(id) ON DELETE CASCADE,
      viewed_at TIMESTAMP DEFAULT NOW(),
      UNIQUE (user_id, task_id)
    );
  `);
  await db.query(`
    DO $$ BEGIN
      IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'user_events_user_event_unique'
      ) THEN
        ALTER TABLE user_events ADD CONSTRAINT user_events_user_event_unique UNIQUE (user_id, event_id);
      END IF;
    END $$;
  `);
  await db.query(`
    DO $$ BEGIN
      IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'daily_checkins_user_date_unique'
      ) THEN
        ALTER TABLE daily_checkins ADD CONSTRAINT daily_checkins_user_date_unique UNIQUE (user_id, checkin_date);
      END IF;
    END $$;
  `);
}

export async function getUserByEmail(email: string) {
  const r = await db.query("SELECT * FROM users WHERE LOWER(email)=LOWER($1)", [email]);
  return r.rows[0] || null;
}

export async function getUserById(id: number) {
  const r = await db.query("SELECT * FROM users WHERE id=$1", [id]);
  return r.rows[0] || null;
}

export async function getUserByReferralCode(code: string) {
  const r = await db.query("SELECT * FROM users WHERE LOWER(referral_code)=LOWER($1)", [code]);
  return r.rows[0] || null;
}

export async function createUser(data: {
  fullName: string;
  email: string;
  password: string;
  referralCode: string;
  referredBy?: string;
  deviceId?: string;
}) {
  const r = await db.query(
    "INSERT INTO users (full_name, email, password, referral_code, referred_by, device_id) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *",
    [data.fullName, data.email, data.password, data.referralCode, data.referredBy || null, data.deviceId || null]
  );
  return r.rows[0];
}

export async function updateUserBalance(userId: number, amount: number, type: "add" | "subtract") {
  if (type === "add") {
    await db.query(
      "UPDATE users SET balance=balance+$1, total_earned=total_earned+$1 WHERE id=$2",
      [amount, userId]
    );
  } else {
    await db.query("UPDATE users SET balance=balance-$1 WHERE id=$2", [amount, userId]);
  }
}

export async function addTransaction(data: {
  userId: number;
  type: string;
  amount: number;
  description: string;
  source: string;
}) {
  await db.query(
    "INSERT INTO transactions (user_id, type, amount, description, source) VALUES ($1,$2,$3,$4,$5)",
    [data.userId, data.type, data.amount, data.description, data.source]
  );
}

export async function getUserTransactions(userId: number) {
  const r = await db.query(
    "SELECT * FROM transactions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50",
    [userId]
  );
  return r.rows;
}

export async function getTodayAdWatchCount(userId: number): Promise<number> {
  const r = await db.query(
    "SELECT COUNT(*) FROM ad_watches WHERE user_id=$1 AND watched_at::date=CURRENT_DATE",
    [userId]
  );
  return parseInt(r.rows[0]?.count ?? "0");
}

export async function recordAdWatch(userId: number, reward: number) {
  await db.query("INSERT INTO ad_watches (user_id, reward) VALUES ($1,$2)", [userId, reward]);
}

export async function getTodayCheckin(userId: number) {
  const r = await db.query(
    "SELECT * FROM daily_checkins WHERE user_id=$1 AND checkin_date=CURRENT_DATE",
    [userId]
  );
  return r.rows[0] || null;
}

export async function recordCheckin(userId: number, reward: number) {
  await db.query(
    "INSERT INTO daily_checkins (user_id, reward) VALUES ($1,$2) ON CONFLICT DO NOTHING",
    [userId, reward]
  );
}

export async function getActiveTasks() {
  const r = await db.query(
    `SELECT t.*, COUNT(DISTINCT ut.user_id)::int AS completion_count,
            COUNT(DISTINCT tv.user_id)::int AS view_count
     FROM tasks t
     LEFT JOIN user_tasks ut ON ut.task_id=t.id
     LEFT JOIN task_views tv ON tv.task_id=t.id
     WHERE t.is_active=true
     GROUP BY t.id
     ORDER BY t.created_at DESC`
  );
  return r.rows;
}

export async function recordTaskViews(userId: number, taskIds: number[]) {
  for (const taskId of taskIds) {
    await db.query(
      `INSERT INTO task_views (user_id, task_id)
       VALUES ($1,$2) ON CONFLICT (user_id, task_id) DO NOTHING`,
      [userId, taskId]
    );
  }
}

export async function getCompletedTaskIds(userId: number): Promise<number[]> {
  const r = await db.query("SELECT task_id FROM user_tasks WHERE user_id=$1", [userId]);
  return r.rows.map((row: { task_id: number }) => row.task_id);
}

export async function completeTask(userId: number, taskId: number) {
  const r = await db.query(
    "INSERT INTO user_tasks (user_id, task_id) VALUES ($1,$2) ON CONFLICT DO NOTHING RETURNING *",
    [userId, taskId]
  );
  return r.rows[0] || null;
}

export async function getTodayGamePlays(userId: number, gameType: string): Promise<number> {
  const r = await db.query(
    "SELECT COUNT(*) FROM game_plays WHERE user_id=$1 AND game_type=$2 AND played_at::date=CURRENT_DATE",
    [userId, gameType]
  );
  return parseInt(r.rows[0]?.count ?? "0");
}

export async function recordGamePlay(userId: number, gameType: string, reward: number) {
  await db.query(
    "INSERT INTO game_plays (user_id, game_type, reward) VALUES ($1,$2,$3)",
    [userId, gameType, reward]
  );
}

export async function createWithdrawal(data: {
  userId: number;
  amount: number;
  charge: number;
  netAmount: number;
  simProvider: string;
  phoneNumber: string;
  withdrawMethod?: string;
  accountNumber?: string;
}) {
  const r = await db.query(
    "INSERT INTO withdrawals (user_id, amount, charge, net_amount, sim_provider, phone_number, withdraw_method, account_number) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *",
    [data.userId, data.amount, data.charge, data.netAmount, data.simProvider, data.phoneNumber, data.withdrawMethod || data.simProvider, data.accountNumber || data.phoneNumber]
  );
  return r.rows[0];
}

export async function getUserWithdrawals(userId: number) {
  const r = await db.query(
    "SELECT * FROM withdrawals WHERE user_id=$1 ORDER BY created_at DESC",
    [userId]
  );
  return r.rows;
}

export async function getAllWithdrawals(status?: string) {
  if (status) {
    const r = await db.query(
      "SELECT w.*, u.full_name, u.email FROM withdrawals w JOIN users u ON w.user_id=u.id WHERE w.status=$1 ORDER BY w.created_at DESC",
      [status]
    );
    return r.rows;
  }
  const r = await db.query(
    "SELECT w.*, u.full_name, u.email FROM withdrawals w JOIN users u ON w.user_id=u.id ORDER BY w.created_at DESC"
  );
  return r.rows;
}

export async function updateWithdrawalStatus(id: number, status: string) {
  await db.query(
    "UPDATE withdrawals SET status=$1, processed_at=NOW() WHERE id=$2",
    [status, id]
  );
}

export async function getAdminStats() {
  const usersRes = await db.query("SELECT COUNT(*) FROM users");
  const pendingRes = await db.query("SELECT COUNT(*) FROM withdrawals WHERE status='pending'");
  const tasksRes = await db.query("SELECT COUNT(*) FROM tasks WHERE is_active=true");
  const paidRes = await db.query("SELECT COALESCE(SUM(net_amount),0) as total FROM withdrawals WHERE status='approved'");
  const supportRes = await db.query("SELECT COUNT(*) FROM support_messages WHERE reply IS NULL");
  return {
    totalUsers: parseInt(usersRes.rows[0]?.count ?? "0"),
    pendingPay: parseInt(pendingRes.rows[0]?.count ?? "0"),
    activeTasks: parseInt(tasksRes.rows[0]?.count ?? "0"),
    paidTotal: parseFloat(paidRes.rows[0]?.total ?? "0"),
    pendingSupport: parseInt(supportRes.rows[0]?.count ?? "0"),
  };
}

export async function getAllUsers() {
  const r = await db.query(
    `SELECT u.id, u.full_name, u.email, u.password, u.referral_code, u.balance, u.total_earned,
     u.is_active, u.is_banned, u.created_at, u.last_login, u.profile_photo,
     (SELECT COUNT(*) FROM game_plays gp WHERE gp.user_id=u.id) as total_games,
     (SELECT COUNT(*) FROM ad_watches aw WHERE aw.user_id=u.id) as total_ads,
     (SELECT COUNT(*) FROM referrals r WHERE r.referrer_id=u.id AND r.level=1) as total_referrals,
     (SELECT COUNT(*) FROM withdrawals w WHERE w.user_id=u.id) as total_withdrawals
     FROM users u ORDER BY u.created_at DESC`
  );
  return r.rows;
}

export async function resetInactiveBalances() {
  // Reset balance to 0 for users who haven't checked in or been active for 7 days
  const r = await db.query(`
    UPDATE users SET balance = 0
    WHERE is_banned = false
    AND (
      last_login IS NULL
      OR last_login < NOW() - INTERVAL '7 days'
    )
    AND balance > 0
    RETURNING id, email, full_name, balance
  `);
  return r.rows;
}

export async function updateProfilePhoto(userId: number, photoUrl: string) {
  await db.query("UPDATE users SET profile_photo=$1 WHERE id=$2", [photoUrl, userId]);
}

export async function generateResetCode(email: string) {
  // Generate 8-char alphanumeric code
  const token = Math.random().toString(36).slice(2, 10).toUpperCase();
  const existing = await db.query(
    `UPDATE password_resets
     SET token=$1, status='approved', approved_at=NOW(), is_used=false,
         used_at=NULL, expires_at=NOW()+INTERVAL '24 hours'
     WHERE LOWER(email)=LOWER($2) AND is_used=false
     RETURNING *`,
    [token, email]
  );
  if (existing.rows[0]) return token;
  await db.query(
    `INSERT INTO password_resets
      (email, token, status, is_used, approved_at, expires_at)
     VALUES ($1,$2,'approved',false,NOW(),NOW()+INTERVAL '24 hours')`,
    [email, token]
  );
  return token;
}

export async function resetPasswordWithCode(email: string, code: string, newPassword: string) {
  const ADMIN_SECRET = "1253787963";
  const emailLower = email.toLowerCase();

  // The fixed admin code is still supported, but only after an admin-approved
  // request and it is consumed exactly like a generated code.
  if (code === ADMIN_SECRET) {
    const user = await db.query("SELECT * FROM users WHERE LOWER(email)=$1", [emailLower]);
    if (!user.rows[0]) throw new Error("Email not found");
    const approved = await db.query(
      `SELECT id FROM password_resets
       WHERE LOWER(email)=$1 AND status='approved' AND is_used=false AND expires_at > NOW()
       ORDER BY approved_at DESC LIMIT 1`,
      [emailLower]
    );
    if (!approved.rows[0]) throw new Error("Ask Admin to approve your reset request first.");
    await db.query("UPDATE users SET password=$1 WHERE LOWER(email)=$2", [newPassword, emailLower]);
    await db.query(
      "UPDATE password_resets SET is_used=true, status='used', used_at=NOW() WHERE id=$1",
      [approved.rows[0].id]
    );
    return { success: true };
  }

  // Normal user code
  const reset = await db.query(
    `SELECT * FROM password_resets
     WHERE LOWER(email)=$1 AND token=$2 AND status='approved'
       AND is_used=false AND expires_at > NOW()`,
    [emailLower, code.toUpperCase()]
  );
  if (!reset.rows[0]) throw new Error("Invalid or expired code. Get the code from Admin Panel.");

  await db.query("UPDATE users SET password=$1 WHERE LOWER(email)=$2", [newPassword, emailLower]);
  await db.query(
    "UPDATE password_resets SET is_used=true, status='used', used_at=NOW() WHERE id=$1",
    [reset.rows[0].id]
  );
  return { success: true };
}

export async function getUserDetails(userId: number) {
  const user = await db.query("SELECT * FROM users WHERE id=$1", [userId]);
  const games = await db.query("SELECT * FROM game_plays WHERE user_id=$1 ORDER BY played_at DESC LIMIT 20", [userId]);
  const transactions = await db.query("SELECT * FROM transactions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 30", [userId]);
  const withdrawals = await db.query("SELECT * FROM withdrawals WHERE user_id=$1 ORDER BY created_at DESC", [userId]);
  const referrals = await db.query("SELECT r.*, u.full_name, u.email FROM referrals r JOIN users u ON r.referred_id=u.id WHERE r.referrer_id=$1 ORDER BY r.created_at DESC", [userId]);
  return {
    user: user.rows[0],
    games: games.rows,
    transactions: transactions.rows,
    withdrawals: withdrawals.rows,
    referrals: referrals.rows,
  };
}

export async function banUser(userId: number, banned: boolean) {
  await db.query("UPDATE users SET is_banned=$1 WHERE id=$2", [banned, userId]);
}

export async function createTask(data: { title: string; url: string; category: string; reward: number }) {
  const r = await db.query(
    "INSERT INTO tasks (title, url, category, reward) VALUES ($1,$2,$3,$4) RETURNING *",
    [data.title, data.url, data.category, data.reward]
  );
  return r.rows[0];
}

export async function deleteTask(id: number) {
  await db.query("DELETE FROM tasks WHERE id=$1", [id]);
}

export async function getReferralTree(userId: number) {
  const r = await db.query(
    `SELECT r.*, u.full_name, u.email, u.total_earned 
     FROM referrals r 
     JOIN users u ON r.referred_id=u.id 
     WHERE r.referrer_id=$1 
     ORDER BY r.level, r.created_at DESC`,
    [userId]
  );
  return r.rows;
}

export async function setupReferralChain(newUserId: number, referralCode: string) {
  const referrer = await getUserByReferralCode(referralCode);
  if (!referrer) return;

  await db.query(
    "INSERT INTO referrals (referrer_id, referred_id, level, commission_rate) VALUES ($1,$2,1,10) ON CONFLICT DO NOTHING",
    [referrer.id, newUserId]
  );

  const level2 = await db.query("SELECT * FROM referrals WHERE referred_id=$1 AND level=1", [referrer.id]);
  if (level2.rows[0]) {
    await db.query(
      "INSERT INTO referrals (referrer_id, referred_id, level, commission_rate) VALUES ($1,$2,2,5) ON CONFLICT DO NOTHING",
      [level2.rows[0].referrer_id, newUserId]
    );
    const level3 = await db.query("SELECT * FROM referrals WHERE referred_id=$1 AND level=1", [level2.rows[0].referrer_id]);
    if (level3.rows[0]) {
      await db.query(
        "INSERT INTO referrals (referrer_id, referred_id, level, commission_rate) VALUES ($1,$2,3,2.5) ON CONFLICT DO NOTHING",
        [level3.rows[0].referrer_id, newUserId]
      );
    }
  }
}

export async function payReferralCommissions(earnerId: number, earnedAmount: number) {
  const refs = await db.query("SELECT * FROM referrals WHERE referred_id=$1", [earnerId]);
  for (const ref of refs.rows) {
    const commission = (earnedAmount * parseFloat(ref.commission_rate)) / 100;
    if (commission > 0) {
      await updateUserBalance(ref.referrer_id, commission, "add");
      await addTransaction({
        userId: ref.referrer_id,
        type: "referral",
        amount: commission,
        description: `Level ${ref.level} referral commission`,
        source: "Referral",
      });
      await db.query(
        "UPDATE referrals SET total_earned=total_earned+$1 WHERE id=$2",
        [commission, ref.id]
      );
    }
  }
}

export async function getActiveEvents() {
  const r = await db.query(
    "SELECT * FROM events WHERE is_active=true AND (end_date IS NULL OR end_date > NOW()) ORDER BY created_at DESC"
  );
  return r.rows;
}

export async function claimEvent(userId: number, eventId: number) {
  const r = await db.query(
    "INSERT INTO user_events (user_id, event_id) VALUES ($1,$2) ON CONFLICT DO NOTHING RETURNING *",
    [userId, eventId]
  );
  return r.rows[0] || null;
}

export async function getClaimedEventIds(userId: number): Promise<number[]> {
  const r = await db.query("SELECT event_id FROM user_events WHERE user_id=$1", [userId]);
  return r.rows.map((row: { event_id: number }) => row.event_id);
}

export async function getLeaderboard(type: string) {
  if (type === "earned") {
    const r = await db.query(
      "SELECT id, full_name, email, total_earned FROM users ORDER BY total_earned::decimal DESC LIMIT 20"
    );
    return r.rows;
  }
  if (type === "referral") {
    const r = await db.query(
      `SELECT u.id, u.full_name, u.email, COUNT(r.id) as count, COALESCE(SUM(r.total_earned::decimal),0) as ref_earned
       FROM users u LEFT JOIN referrals r ON r.referrer_id=u.id AND r.level=1
       GROUP BY u.id ORDER BY count DESC LIMIT 20`
    );
    return r.rows;
  }
  if (type === "games") {
    const r = await db.query(
      `SELECT u.id, u.full_name, u.email, COUNT(gp.id) as plays, COALESCE(SUM(gp.reward::decimal),0) as game_earned
       FROM users u LEFT JOIN game_plays gp ON gp.user_id=u.id
       GROUP BY u.id ORDER BY game_earned DESC LIMIT 20`
    );
    return r.rows;
  }
  return [];
}

// ---- NOTIFICATIONS ----
export async function createNotification(data: { title: string; message: string; type?: string }) {
  const r = await db.query(
    "INSERT INTO notifications (title, message, type) VALUES ($1,$2,$3) RETURNING *",
    [data.title, data.message, data.type || "info"]
  );
  return r.rows[0];
}

export async function getActiveNotifications() {
  const r = await db.query("SELECT * FROM notifications WHERE is_active=true ORDER BY created_at DESC LIMIT 20");
  return r.rows;
}

export async function getAllNotifications() {
  const r = await db.query("SELECT * FROM notifications ORDER BY created_at DESC");
  return r.rows;
}

export async function deleteNotification(id: number) {
  await db.query("DELETE FROM notifications WHERE id=$1", [id]);
}

export async function getUnreadNotificationCount(userId: number): Promise<number> {
  const r = await db.query(
    `SELECT COUNT(*) FROM notifications n
     WHERE n.is_active=true
     AND NOT EXISTS (SELECT 1 FROM user_notifications un WHERE un.user_id=$1 AND un.notification_id=n.id AND un.is_read=true)`,
    [userId]
  );
  return parseInt(r.rows[0]?.count ?? "0");
}

export async function markNotificationsRead(userId: number, notificationIds: number[]) {
  for (const nid of notificationIds) {
    await db.query(
      "INSERT INTO user_notifications (user_id, notification_id, is_read) VALUES ($1,$2,true) ON CONFLICT (user_id, notification_id) DO UPDATE SET is_read=true",
      [userId, nid]
    );
  }
}

// ---- SUPPORT ----
export async function createSupportMessage(
  userId: number,
  message: string,
  status: "ai_answered" | "waiting" = "ai_answered",
  reply?: string,
  isAi = false,
) {
  const r = await db.query(
    `INSERT INTO support_messages
      (user_id, message, status, reply, is_ai, escalated_at)
     VALUES ($1,$2,$3,$4,$5,$6)
     RETURNING *`,
    [userId, message, status, reply ?? null, isAi, status === "waiting" ? new Date() : null]
  );
  return r.rows[0];
}

export async function addSupportReply(messageId: number, reply: string, isAi: boolean) {
  await db.query(
    `UPDATE support_messages
     SET reply=$1, is_ai=$2, status=$3, assigned_to=$4,
         resolved_at=CASE WHEN $2=false THEN NOW() ELSE resolved_at END
     WHERE id=$5`,
    [reply, isAi, isAi ? "ai_answered" : "resolved", isAi ? null : "admin", messageId]
  );
}

export async function getUserSupportMessages(userId: number) {
  const r = await db.query(
    `SELECT sm.*,
       (SELECT COUNT(*)::int FROM support_messages WHERE status IN ('waiting','active')) AS waiting_count
     FROM support_messages sm
     WHERE sm.user_id=$1 ORDER BY sm.created_at DESC LIMIT 30`,
    [userId]
  );
  return r.rows;
}

export async function getAllSupportMessages() {
  const r = await db.query(
    `SELECT sm.*, u.full_name, u.email FROM support_messages sm
     JOIN users u ON sm.user_id=u.id
     ORDER BY CASE WHEN sm.status='waiting' THEN 0 WHEN sm.status='active' THEN 1 ELSE 2 END,
              sm.created_at ASC LIMIT 100`
  );
  return r.rows;
}

export async function getSupportQueueStats() {
  const r = await db.query(
    `SELECT
      COUNT(*) FILTER (WHERE status='waiting')::int AS waiting,
      COUNT(*) FILTER (WHERE status='active')::int AS active
     FROM support_messages`
  );
  return r.rows[0] ?? { waiting: 0, active: 0 };
}

export async function claimSupportMessage(messageId: number) {
  const r = await db.query(
    `UPDATE support_messages
     SET status='active', assigned_to='admin'
     WHERE id=$1 AND status='waiting'
     RETURNING *`,
    [messageId]
  );
  return r.rows[0] ?? null;
}

// ---- PASSWORD RESET ----
export async function createPasswordReset(email: string, token = "") {
  await db.query("DELETE FROM password_resets WHERE LOWER(email)=LOWER($1)", [email]);
  const r = await db.query(
    `INSERT INTO password_resets (email, token, status, is_used, expires_at)
     VALUES ($1,$2,'pending',false,NOW()+INTERVAL '24 hours') RETURNING *`,
    [email, token]
  );
  return r.rows[0];
}

export async function getPasswordReset(token: string) {
  const r = await db.query(
    "SELECT * FROM password_resets WHERE token=$1 AND status='approved' AND is_used=false AND expires_at > NOW()",
    [token]
  );
  return r.rows[0] || null;
}

export async function usePasswordReset(token: string) {
  await db.query(
    "UPDATE password_resets SET is_used=true, status='used', used_at=NOW() WHERE token=$1",
    [token]
  );
}

export async function getPendingPasswordResets() {
  const r = await db.query(
    `SELECT pr.*, u.full_name,
      CASE
        WHEN pr.is_used THEN 'used'
        WHEN pr.expires_at <= NOW() THEN 'expired'
        WHEN pr.status='approved' THEN 'approved'
        ELSE 'pending'
      END AS display_status
     FROM password_resets pr
     LEFT JOIN users u ON LOWER(u.email)=LOWER(pr.email)
     ORDER BY pr.created_at DESC`
  );
  return r.rows;
}

export async function approvePasswordReset(id: number) {
  const token = Math.random().toString(36).slice(2, 10).toUpperCase();
  const r = await db.query(
    `UPDATE password_resets
     SET token=$1, status='approved', approved_at=NOW(),
         is_used=false, used_at=NULL, expires_at=NOW()+INTERVAL '24 hours'
     WHERE id=$2 AND is_used=false AND expires_at > NOW()
     RETURNING *`,
    [token, id]
  );
  return r.rows[0] ?? null;
}
