import type { Express, Request, Response } from "express";
import { createServer, type Server } from "node:http";
import { randomBytes } from "node:crypto";
import * as storage from "./storage";

const ADMIN_EMAIL = "kajolchandradas3@gmail.com";
const ADMIN_TOKEN_TTL_MS = 12 * 60 * 60 * 1000;
const adminTokens = new Map<string, number>();

function requireAuth(req: Request, res: Response): number | null {
  const userId = req.headers["x-user-id"];
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return null;
  }
  return parseInt(userId as string);
}

function issueAdminToken(): string {
  const token = `admin-${randomBytes(32).toString("hex")}`;
  adminTokens.set(token, Date.now() + ADMIN_TOKEN_TTL_MS);
  return token;
}

const DEFAULT_SETTINGS: Record<string, string> = {
  ads_enabled: "true",
  ads_on_click: "false",
  ads_on_claim: "true",
  ads_on_game: "true",
  ads_on_watch: "true",
  ads_on_checkin: "true",
  ads_on_event: "true",
  ads_on_withdrawal: "false",
  ad_reward: "0.5",
  max_ads_per_day: "10",
  ad_duration: "5",
  ad_click_cooldown: "60",
  ad_max_per_session: "20",
  ad_network: "monetag",
  ad_zone_id: "",
  ad_zone_interstitial: "",
  ad_zone_rewarded: "",
  ad_zone_native: "",
  ad_zone_game: "",
  ad_zone_claim: "",
  ad_zone_click: "",
  checkin_reward: "0.5",
  min_withdraw: "50",
  withdraw_charge: "10",
  ref_bonus_l1: "10",
  ref_bonus_l2: "5",
  ref_bonus_l3: "2.5",
  game_min_reward: "0.1",
  game_max_reward: "3",
  free_plays_per_day: "1",
  ad_plays_per_game: "1",
  spin_wheel_prizes: JSON.stringify([{amount:0.1,pct:25},{amount:0.2,pct:20},{amount:0.5,pct:20},{amount:1.0,pct:15},{amount:1.5,pct:10},{amount:2.0,pct:6},{amount:2.5,pct:3},{amount:3.0,pct:1}]),
  spin_split_prizes: JSON.stringify([{amount:0.1,pct:25},{amount:0.2,pct:20},{amount:0.5,pct:20},{amount:1.0,pct:15},{amount:1.5,pct:10},{amount:2.0,pct:6},{amount:2.5,pct:3},{amount:3.0,pct:1}]),
  scratch_prizes: JSON.stringify([{amount:0.1,pct:30},{amount:0.2,pct:25},{amount:0.5,pct:20},{amount:1.0,pct:15},{amount:2.0,pct:8},{amount:3.0,pct:2}]),
  lucky_spin_match_pct: "30",
  lucky_spin_match_reward: "3",
  lucky_spin_nomatch_min: "0.1",
  lucky_spin_nomatch_max: "0.5",
  device_id_tracking: "false",
  one_account_per_phone: "false",
  max_withdrawal_per_day: "500",
  require_email_verify: "false",
  auto_approve_withdrawal: "false",
  maintenance_mode: "false",
  referral_system: "true",
  support_link: "",
  telegram_support_link: "",
  // Withdrawal method settings
  withdraw_binance_enabled: "true",
  withdraw_binance_min: "1",
  withdraw_binance_max: "500",
  withdraw_bkash_enabled: "true",
  withdraw_bkash_min: "50",
  withdraw_bkash_max: "5000",
  withdraw_nagad_enabled: "true",
  withdraw_nagad_min: "50",
  withdraw_nagad_max: "5000",
  withdraw_recharge_enabled: "true",
  withdraw_recharge_min: "20",
  withdraw_recharge_max: "500",
  binance_usd_rate: "110",
};

async function initializeDefaults() {
  await storage.ensureAdminAuth();
  await storage.ensureDbConstraints();
  for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
    const existing = await storage.getSetting(key);
    if (existing === null) {
      await storage.setSetting(key, value);
    }
  }
}

// Simple AI support response generator
function generateAIResponse(message: string): string | null {
  const msg = message.toLowerCase();

  if (msg.includes("withdraw") || msg.includes("টাকা তোলা") || msg.includes("payment")) {
    return "আপনার withdrawal সম্পর্কে জানতে চাইছেন? Minimum withdrawal হলো 50 TK। Binance Pay UID, BKash, Nagad বা Mobile Recharge এর মাধ্যমে withdraw করতে পারবেন। Wallet tab থেকে Withdraw অপশন ব্যবহার করুন। সাধারণত 24 ঘন্টার মধ্যে প্রসেস হয়।";
  }
  if (msg.includes("balance") || msg.includes("ব্যালেন্স")) {
    return "আপনার balance Home screen এ দেখতে পাবেন। Balance কম মনে হলে আরো ads watch করুন, games খেলুন বা referral করুন। প্রতিটি ad watch করলে reward পাবেন।";
  }
  if (msg.includes("referral") || msg.includes("রেফার")) {
    return "Referral code দিয়ে বন্ধুদের invite করুন। Level 1 referral থেকে 10%, Level 2 থেকে 5%, Level 3 থেকে 2.5% commission পাবেন। Profile tab থেকে আপনার referral code পাবেন।";
  }
  if (msg.includes("game") || msg.includes("গেম") || msg.includes("spin") || msg.includes("scratch")) {
    return "প্রতিটি game এ দিনে 1টি free play আছে। 1টি ad দেখলে extra 1টি play পাবেন। Spin Wheel, Scratch Card, Spin & Split, Lucky Spin 3X খেলতে পারবেন। প্রতি game এ 0.1 থেকে 3 TK জিততে পারবেন।";
  }
  if (msg.includes("ad") || msg.includes("এড") || msg.includes("ads")) {
    return "Earn tab থেকে ads watch করে TK উপার্জন করুন। প্রতিদিন নির্দিষ্ট সংখ্যক ads দেখতে পারবেন। প্রতিটি ad এর জন্য reward পাবেন যা সরাসরি balance এ যোগ হবে।";
  }
  if (msg.includes("login") || msg.includes("password") || msg.includes("লগইন") || msg.includes("পাসওয়ার্ড")) {
    return "Login করতে আপনার Gmail এবং password ব্যবহার করুন। Password ভুলে গেলে Login screen এ 'Forgot Password' option ব্যবহার করুন। সমস্যা হলে admin এর সাথে যোগাযোগ করুন।";
  }
  if (msg.includes("ban") || msg.includes("block") || msg.includes("বান")) {
    return "আপনার account ban হলে admin এর সাথে যোগাযোগ করুন। Terms of Service অনুযায়ী ব্যবহার করলে account ban হবে না। Telegram এর মাধ্যমে সরাসরি admin এর সাথে কথা বলতে পারবেন।";
  }
  if (msg.includes("check in") || msg.includes("checkin") || msg.includes("চেক ইন")) {
    return "প্রতিদিন একবার Daily Check-in করতে পারবেন। Home screen এ 'Daily Check-In' button এ tap করুন। এতে extra TK reward পাবেন।";
  }

  // Do not invent an answer for an unsupported question. The caller escalates
  // this message to the human support queue instead.
  return null;
}

export async function registerRoutes(app: Express): Promise<Server> {

  await initializeDefaults();

  // ======= AUTH =======
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { fullName, password, deviceId } = req.body;
      const email = String(req.body.email ?? "").trim().toLowerCase();
      const requestedReferralCode = String(req.body.referralCode ?? "").trim();
      if (!fullName || !email || !password) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const existing = await storage.getUserByEmail(email);
      if (existing) return res.status(400).json({ error: "Email already registered" });

      const onePerPhone = await storage.getSetting("one_account_per_phone");
      const deviceTracking = await storage.getSetting("device_id_tracking");
      if (deviceTracking === "true" && deviceId) {
        const deviceCheck = await storage.db.query("SELECT id FROM users WHERE device_id=$1", [deviceId]);
        if (deviceCheck.rows.length > 0 && onePerPhone === "true") {
          return res.status(400).json({ error: "One account per device allowed" });
        }
      }

      const emailUsername = email.split("@")[0];
      const adminUser = await storage.getUserByEmail(ADMIN_EMAIL);
      let appliedReferralCode: string | undefined;

      // An explicitly supplied code is used only when it belongs to a real
      // user. Otherwise every regular signup falls back to the admin.
      if (requestedReferralCode) {
        const referrer = await storage.getUserByReferralCode(requestedReferralCode);
        if (referrer && referrer.email.toLowerCase() !== email) {
          appliedReferralCode = referrer.referral_code;
        }
      }
      if (!appliedReferralCode && email !== ADMIN_EMAIL.toLowerCase() && adminUser) {
        appliedReferralCode = adminUser.referral_code;
      }

      const user = await storage.createUser({
        fullName,
        email,
        password,
        referralCode: emailUsername,
        referredBy: appliedReferralCode,
        deviceId,
      });

      if (appliedReferralCode) {
        await storage.setupReferralChain(user.id, appliedReferralCode);
      }

      const isAdmin = email.toLowerCase() === ADMIN_EMAIL.toLowerCase();
      res.json({ user: { ...sanitizeUser(user), isAdmin } });
    } catch (err: unknown) {
      const error = err as Error;
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password, deviceId } = req.body;
      const user = await storage.getUserByEmail(email);
      if (!user || user.password !== password) {
        return res.status(401).json({ error: "Invalid email or password" });
      }
      if (user.is_banned) {
        return res.status(403).json({ error: "Account suspended" });
      }

      const deviceTracking = await storage.getSetting("device_id_tracking");
      const onePerPhone = await storage.getSetting("one_account_per_phone");
      if (deviceTracking === "true" && deviceId && user.device_id && user.device_id !== deviceId && onePerPhone === "true") {
        return res.status(403).json({ error: "This account is linked to another device" });
      }

      if (deviceId && !user.device_id) {
        await storage.db.query("UPDATE users SET device_id=$1, last_login=NOW() WHERE id=$2", [deviceId, user.id]);
      } else {
        await storage.db.query("UPDATE users SET last_login=NOW() WHERE id=$1", [user.id]);
      }

      const fresh = await storage.getUserById(user.id);
      const isAdmin = email.toLowerCase() === ADMIN_EMAIL.toLowerCase();
      res.json({ user: { ...sanitizeUser(fresh), isAdmin } });
    } catch (err: unknown) {
      const error = err as Error;
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/auth/me", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const user = await storage.getUserById(userId);
    if (!user) return res.status(404).json({ error: "User not found" });
    const isAdmin = user.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase();
    res.json({ user: { ...sanitizeUser(user), isAdmin } });
  });

  app.put("/api/auth/profile", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const { fullName } = req.body;
    await storage.db.query("UPDATE users SET full_name=$1 WHERE id=$2", [fullName, userId]);
    const user = await storage.getUserById(userId);
    const isAdmin = user.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase();
    res.json({ user: { ...sanitizeUser(user), isAdmin } });
  });

  // ======= PASSWORD RESET =======
  // Step 1: user submits email → code stored in DB → admin sees it
  app.post("/api/auth/forgot-password", async (req, res) => {
    try {
      const { email } = req.body;
      if (!email) return res.status(400).json({ error: "Email required" });
      const user = await storage.getUserByEmail(email.toLowerCase());
      if (!user) return res.status(404).json({ error: "No account found with this email" });
      await storage.createPasswordReset(email.toLowerCase());
      res.json({ success: true, message: "Request submitted. Admin will review it and generate your secret reset code." });
    } catch (err: unknown) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  // Step 2: user enters email + admin-provided code + new password
  app.post("/api/auth/reset-password", async (req, res) => {
    try {
      const { email, code, newPassword } = req.body;
      if (!email || !code || !newPassword) return res.status(400).json({ error: "Email, code, and new password required" });
      if (newPassword.length < 6) return res.status(400).json({ error: "Password must be at least 6 characters" });
      await storage.resetPasswordWithCode(email.trim().toLowerCase(), code.trim(), newPassword);
      res.json({ success: true });
    } catch (err: unknown) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  // Profile photo update
  app.put("/api/auth/profile-photo", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const { photoUrl } = req.body;
    if (!photoUrl) return res.status(400).json({ error: "Photo URL required" });
    await storage.updateProfilePhoto(userId, photoUrl);
    const user = await storage.getUserById(userId);
    const isAdmin = user.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase();
    res.json({ user: { ...sanitizeUser(user), isAdmin } });
  });

  // ======= ADS =======
  app.post("/api/ads/watch", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      const settings = await storage.getSettings();
      if (settings.ads_enabled !== "true") {
        return res.status(400).json({ error: "Ads are currently disabled" });
      }
      const maxAds = parseInt(settings.max_ads_per_day ?? "9");
      const watched = await storage.getTodayAdWatchCount(userId);
      if (watched >= maxAds) {
        return res.status(400).json({ error: "Daily ad limit reached", breakTime: parseInt(settings.break_time_minutes ?? "60") });
      }
      const reward = parseFloat(settings.ad_reward ?? "0.5");
      await storage.recordAdWatch(userId, reward);
      await storage.updateUserBalance(userId, reward, "add");
      await storage.addTransaction({
        userId,
        type: "ads",
        amount: reward,
        description: "Watched rewarded video ad",
        source: "Ads",
      });
      await storage.payReferralCommissions(userId, reward);

      const remaining = maxAds - watched - 1;
      res.json({ reward, watched: watched + 1, remaining, maxAds });
    } catch (err: unknown) {
      const error = err as Error;
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/ads/status", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const settings = await storage.getSettings();
    const watched = await storage.getTodayAdWatchCount(userId);
    const maxAds = parseInt(settings.max_ads_per_day ?? "9");
    res.json({
      watched,
      maxAds,
      remaining: Math.max(0, maxAds - watched),
      reward: parseFloat(settings.ad_reward ?? "0.5"),
      adsEnabled: settings.ads_enabled === "true",
    });
  });

  // ======= DAILY CHECK-IN =======
  app.post("/api/checkin", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      const existing = await storage.getTodayCheckin(userId);
      if (existing) return res.status(400).json({ error: "Already checked in today" });

      const rewardStr = await storage.getSetting("checkin_reward");
      const reward = parseFloat(rewardStr ?? "0.5");
      await storage.recordCheckin(userId, reward);
      await storage.updateUserBalance(userId, reward, "add");
      await storage.addTransaction({
        userId,
        type: "checkin",
        amount: reward,
        description: "Daily check-in bonus",
        source: "Daily Task",
      });
      res.json({ reward });
    } catch (err: unknown) {
      const error = err as Error;
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/checkin/status", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const checkin = await storage.getTodayCheckin(userId);
    const rewardStr = await storage.getSetting("checkin_reward");
    res.json({ checkedIn: !!checkin, reward: parseFloat(rewardStr ?? "0.5") });
  });

  // ======= TASKS =======
  app.get("/api/tasks", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const tasks = await storage.getActiveTasks();
    await storage.recordTaskViews(userId, tasks.map((task: { id: number }) => task.id));
    const completed = await storage.getCompletedTaskIds(userId);
    res.json({ tasks, completed });
  });

  app.post("/api/tasks/:id/complete", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      const taskId = parseInt(req.params.id);
      const tasks = await storage.getActiveTasks();
      const task = tasks.find((t: { id: number }) => t.id === taskId);
      if (!task) return res.status(404).json({ error: "Task not found" });

      const result = await storage.completeTask(userId, taskId);
      if (!result) return res.status(400).json({ error: "Task already completed" });

      const reward = parseFloat(task.reward);
      await storage.updateUserBalance(userId, reward, "add");
      await storage.addTransaction({
        userId,
        type: "task",
        amount: reward,
        description: `Completed: ${task.title}`,
        source: "Daily Task",
      });
      await storage.payReferralCommissions(userId, reward);
      res.json({ reward });
    } catch (err: unknown) {
      const error = err as Error;
      res.status(500).json({ error: error.message });
    }
  });

  // ======= GAMES =======
  function pickByProbability(prizes: {amount: number, pct: number}[]): {prize: {amount: number, pct: number}, index: number} {
    const total = prizes.reduce((s, p) => s + p.pct, 0);
    let rand = Math.random() * total;
    for (let i = 0; i < prizes.length; i++) {
      rand -= prizes[i].pct;
      if (rand <= 0) return { prize: prizes[i], index: i };
    }
    return { prize: prizes[prizes.length - 1], index: prizes.length - 1 };
  }

  const LUCKY_SYMBOLS = ["🍎","🍊","🍋","🍇","🍓","🌸","🌺","🦁","🐯","🐸"];
  const DEFAULT_SPIN_PRIZES = [{amount:0.1,pct:25},{amount:0.2,pct:20},{amount:0.5,pct:20},{amount:1.0,pct:15},{amount:1.5,pct:10},{amount:2.0,pct:6},{amount:2.5,pct:3},{amount:3.0,pct:1}];
  const DEFAULT_SCRATCH_PRIZES = [{amount:0.1,pct:30},{amount:0.2,pct:25},{amount:0.5,pct:20},{amount:1.0,pct:15},{amount:2.0,pct:8},{amount:3.0,pct:2}];

  app.post("/api/games/play", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      const { gameType, usedAd } = req.body;
      const settings = await storage.getSettings();
      const freePlays = parseInt(settings.free_plays_per_day ?? "1");
      const adPlays = parseInt(settings.ad_plays_per_game ?? "1");
      const todayPlays = await storage.getTodayGamePlays(userId, gameType);
      const allowedPlays = freePlays + adPlays;

      if (todayPlays >= allowedPlays) {
        return res.status(400).json({ error: "No plays remaining for today" });
      }
      if (todayPlays >= freePlays && !usedAd) {
        return res.status(400).json({ error: "Watch an ad to play again", requireAd: true });
      }

      let reward = 0;
      let segmentIndex = 0;
      let symbols: string[] = [];
      let isMatch = false;

      if (gameType === "lucky_spin") {
        const matchPct = parseFloat(settings.lucky_spin_match_pct ?? "30");
        isMatch = Math.random() * 100 < matchPct;
        if (isMatch) {
          const sym = LUCKY_SYMBOLS[Math.floor(Math.random() * LUCKY_SYMBOLS.length)];
          symbols = [sym, sym, sym];
          reward = parseFloat(settings.lucky_spin_match_reward ?? "3");
        } else {
          const shuffled = [...LUCKY_SYMBOLS].sort(() => Math.random() - 0.5);
          const chosen: string[] = [];
          for (const s of shuffled) {
            if (!chosen.includes(s)) chosen.push(s);
            if (chosen.length === 3) break;
          }
          // Make sure they're different
          while (chosen[0] === chosen[1] || chosen[1] === chosen[2] || chosen[0] === chosen[2]) {
            const idx = Math.floor(Math.random() * LUCKY_SYMBOLS.length);
            chosen[Math.floor(Math.random() * 3)] = LUCKY_SYMBOLS[idx];
          }
          symbols = chosen;
          const minR = parseFloat(settings.lucky_spin_nomatch_min ?? "0.1");
          const maxR = parseFloat(settings.lucky_spin_nomatch_max ?? "0.5");
          reward = Math.round((Math.random() * (maxR - minR) + minR) * 100) / 100;
        }
      } else if (gameType === "scratch_card") {
        let prizes = DEFAULT_SCRATCH_PRIZES;
        try { prizes = JSON.parse(settings.scratch_prizes ?? ""); } catch {}
        const result = pickByProbability(prizes);
        reward = result.prize.amount;
        segmentIndex = result.index;
      } else if (gameType === "spin_split") {
        let prizes = DEFAULT_SPIN_PRIZES;
        try { prizes = JSON.parse(settings.spin_split_prizes ?? ""); } catch {}
        const result = pickByProbability(prizes);
        reward = result.prize.amount;
        segmentIndex = result.index;
      } else {
        let prizes = DEFAULT_SPIN_PRIZES;
        try { prizes = JSON.parse(settings.spin_wheel_prizes ?? ""); } catch {}
        const result = pickByProbability(prizes);
        reward = result.prize.amount;
        segmentIndex = result.index;
      }

      await storage.recordGamePlay(userId, gameType, reward);
      await storage.updateUserBalance(userId, reward, "add");
      await storage.addTransaction({
        userId, type: "game", amount: reward,
        description: `Played ${gameType}`, source: "Games",
      });
      await storage.payReferralCommissions(userId, reward);

      res.json({ reward, playsUsed: todayPlays + 1, allowedPlays, segmentIndex, symbols, isMatch });
    } catch (err: unknown) {
      const error = err as Error;
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/games/status", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const { gameType } = req.query;
    const settings = await storage.getSettings();
    const freePlays = parseInt(settings.free_plays_per_day ?? "1");
    const adPlays = parseInt(settings.ad_plays_per_game ?? "1");
    const todayPlays = await storage.getTodayGamePlays(userId, gameType as string);
    res.json({
      todayPlays,
      freePlays,
      adPlays,
      allowedPlays: freePlays + adPlays,
      remaining: Math.max(0, freePlays + adPlays - todayPlays),
    });
  });

  // ======= WITHDRAWALS =======
  app.post("/api/withdrawals", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      const { amount, withdrawMethod, accountNumber, simProvider, phoneNumber } = req.body;
      const settings = await storage.getSettings();
      const minWithdraw = parseFloat(settings.min_withdraw ?? "50");
      const chargeRate = parseFloat(settings.withdraw_charge ?? "10");

      const method = withdrawMethod || simProvider || "bkash";
      const account = accountNumber || phoneNumber || "";

      // Check method-specific min/max
      const methodKey = method === "binance" ? "binance" : method === "bkash" ? "bkash" : method === "nagad" ? "nagad" : "recharge";
      const methodMin = parseFloat(settings[`withdraw_${methodKey}_min`] ?? String(minWithdraw));
      const methodMax = parseFloat(settings[`withdraw_${methodKey}_max`] ?? "999999");
      const methodEnabled = settings[`withdraw_${methodKey}_enabled`] !== "false";

      if (!methodEnabled) {
        return res.status(400).json({ error: `${method} withdrawal is currently disabled` });
      }
      if (amount < methodMin) {
        return res.status(400).json({ error: `Minimum withdrawal for ${method} is ${methodMin}` });
      }
      if (amount > methodMax) {
        return res.status(400).json({ error: `Maximum withdrawal for ${method} is ${methodMax}` });
      }

      const user = await storage.getUserById(userId);
      if (parseFloat(user.balance) < amount) {
        return res.status(400).json({ error: "Insufficient balance" });
      }

      const charge = (amount * chargeRate) / 100;
      const netAmount = amount - charge;

      // For Binance, convert TK to USD
      let displayNet = netAmount;
      let currency = "TK";
      if (method === "binance") {
        const usdRate = parseFloat(settings.binance_usd_rate ?? "110");
        displayNet = Math.round((netAmount / usdRate) * 100) / 100;
        currency = "USD";
      }

      await storage.updateUserBalance(userId, amount, "subtract");
      const withdrawal = await storage.createWithdrawal({
        userId,
        amount,
        charge,
        netAmount: method === "binance" ? displayNet : netAmount,
        simProvider: method,
        phoneNumber: account,
        withdrawMethod: method,
        accountNumber: account,
      });
      await storage.addTransaction({
        userId,
        type: "withdrawal",
        amount: -amount,
        description: `Withdrawal via ${method} to ${account}`,
        source: "Withdrawal",
      });

      res.json({ withdrawal, currency, displayNet });
    } catch (err: unknown) {
      const error = err as Error;
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/withdrawals", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const withdrawals = await storage.getUserWithdrawals(userId);
    res.json({ withdrawals });
  });

  // ======= TRANSACTIONS =======
  app.get("/api/transactions", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const transactions = await storage.getUserTransactions(userId);
    res.json({ transactions });
  });

  // ======= REFERRALS =======
  app.get("/api/referrals", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const tree = await storage.getReferralTree(userId);
    res.json({ referrals: tree });
  });

  // ======= EVENTS =======
  app.get("/api/events", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const events = await storage.getActiveEvents();
    const claimed = await storage.getClaimedEventIds(userId);
    res.json({ events, claimed });
  });

  app.post("/api/events/:id/claim", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      const eventId = parseInt(req.params.id);
      const events = await storage.getActiveEvents();
      const event = events.find((e: { id: number }) => e.id === eventId);
      if (!event) return res.status(404).json({ error: "Event not found" });

      const result = await storage.claimEvent(userId, eventId);
      if (!result) return res.status(400).json({ error: "Already claimed" });

      const reward = parseFloat(event.reward);
      await storage.updateUserBalance(userId, reward, "add");
      await storage.addTransaction({
        userId,
        type: "event",
        amount: reward,
        description: `Event bonus: ${event.title}`,
        source: "Event Bonus",
      });
      res.json({ reward });
    } catch (err: unknown) {
      const error = err as Error;
      res.status(500).json({ error: error.message });
    }
  });

  // ======= LEADERBOARD =======
  app.get("/api/leaderboard/:type", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const board = await storage.getLeaderboard(req.params.type);
    res.json({ leaderboard: board });
  });

  // ======= NOTIFICATIONS =======
  app.get("/api/notifications", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const notifications = await storage.getActiveNotifications();
    const count = await storage.getUnreadNotificationCount(userId);
    res.json({ notifications, unreadCount: count });
  });

  app.post("/api/notifications/read", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const { notificationIds } = req.body;
    await storage.markNotificationsRead(userId, notificationIds || []);
    res.json({ success: true });
  });

  // ======= SUPPORT =======
  app.get("/api/support/messages", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const messages = await storage.getUserSupportMessages(userId);
    res.json({ messages });
  });

  app.post("/api/support/send", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      const { message } = req.body;
      if (!message?.trim()) return res.status(400).json({ error: "Message required" });

      const liveRequest = /\b(live\s*(support|chat|agent))\b/i.test(message) ||
        message.toLowerCase().includes("লাইভ সাপোর্ট") ||
        message.toLowerCase().includes("লাইভ চ্যাট");
      const aiReply = liveRequest ? null : generateAIResponse(message);
      const msg = await storage.createSupportMessage(
        userId,
        message,
        aiReply ? "ai_answered" : "waiting",
        aiReply ?? "আপনার message live support queue-তে পাঠানো হয়েছে। Admin যত দ্রুত সম্ভব উত্তর দেবেন।",
        !!aiReply,
      );
      const queue = await storage.getSupportQueueStats();

      res.json({ message: msg, aiReply, liveSupport: !aiReply, queue });
    } catch (err: unknown) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  // ======= SETTINGS (public) =======
  app.get("/api/settings/public", async (_req, res) => {
    const settings = await storage.getSettings();
    const pub: Record<string, string> = {};
    const publicKeys = [
      "ads_enabled", "ads_on_click", "ads_on_game", "ads_on_claim", "ads_on_watch",
      "ads_on_checkin", "ads_on_event",
      "ad_reward", "max_ads_per_day", "min_withdraw", "withdraw_charge",
      "support_link", "telegram_support_link", "checkin_reward", "game_min_reward", "game_max_reward",
      "free_plays_per_day", "ad_plays_per_game",
      "ad_zone_id", "ad_zone_interstitial", "ad_zone_rewarded", "ad_zone_native",
      "ad_network", "ad_duration", "ad_click_cooldown", "ad_max_per_session",
      "ad_zone_game", "ad_zone_claim", "ad_zone_click",
      "spin_wheel_prizes", "spin_split_prizes", "scratch_prizes",
      "lucky_spin_match_pct", "lucky_spin_match_reward", "lucky_spin_nomatch_min", "lucky_spin_nomatch_max",
      "withdraw_binance_enabled", "withdraw_binance_min", "withdraw_binance_max",
      "withdraw_bkash_enabled", "withdraw_bkash_min", "withdraw_bkash_max",
      "withdraw_nagad_enabled", "withdraw_nagad_min", "withdraw_nagad_max",
      "withdraw_recharge_enabled", "withdraw_recharge_min", "withdraw_recharge_max",
      "binance_usd_rate",
    ];
    for (const k of publicKeys) pub[k] = settings[k] ?? "";
    res.json(pub);
  });

  // ======= ADMIN AUTH =======
  app.post("/api/admin/login", async (req, res) => {
    const { pin } = req.body;
    const adminPin = await storage.getAdminPin();
    if (pin !== adminPin) return res.status(401).json({ error: "Invalid PIN" });
    res.json({ success: true, token: issueAdminToken() });
  });

  // Email-based admin login
  app.post("/api/admin/email-login", async (req, res) => {
    const { email, password } = req.body;
    if (email?.toLowerCase() !== ADMIN_EMAIL.toLowerCase()) {
      return res.status(401).json({ error: "Not authorized as admin" });
    }
    const user = await storage.getUserByEmail(email.toLowerCase());
    if (!user || user.password !== password) {
      return res.status(401).json({ error: "Invalid credentials" });
    }
    res.json({ success: true, token: issueAdminToken() });
  });

  app.post("/api/admin/change-pin", async (req, res) => {
    const { currentPin, newPin } = req.body;
    const adminPin = await storage.getAdminPin();
    if (currentPin !== adminPin) return res.status(401).json({ error: "Current PIN is incorrect" });
    await storage.setAdminPin(newPin);
    res.json({ success: true });
  });

  // ======= ADMIN DASHBOARD =======
  app.get("/api/admin/stats", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const stats = await storage.getAdminStats();
    res.json(stats);
  });

  app.get("/api/admin/settings", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const settings = await storage.getSettings();
    res.json(settings);
  });

  app.post("/api/admin/settings", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const settings = req.body;
    for (const [key, value] of Object.entries(settings)) {
      await storage.setSetting(key, String(value));
    }
    res.json({ success: true });
  });

  app.get("/api/admin/users", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const users = await storage.getAllUsers();
    res.json({ users });
  });

  app.get("/api/admin/users/:id", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const details = await storage.getUserDetails(parseInt(req.params.id));
    res.json(details);
  });

  app.post("/api/admin/users/:id/ban", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { banned } = req.body;
    await storage.banUser(parseInt(req.params.id), banned);
    res.json({ success: true });
  });

  app.get("/api/admin/withdrawals", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { status } = req.query;
    const withdrawals = await storage.getAllWithdrawals(status as string | undefined);
    res.json({ withdrawals });
  });

  app.post("/api/admin/withdrawals/:id/approve", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    await storage.updateWithdrawalStatus(parseInt(req.params.id), "approved");
    res.json({ success: true });
  });

  app.post("/api/admin/withdrawals/:id/reject", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const withdrawal = await storage.db.query("SELECT * FROM withdrawals WHERE id=$1", [req.params.id]);
    if (withdrawal.rows[0] && withdrawal.rows[0].status === "pending") {
      await storage.updateUserBalance(withdrawal.rows[0].user_id, parseFloat(withdrawal.rows[0].amount), "add");
    }
    await storage.updateWithdrawalStatus(parseInt(req.params.id), "rejected");
    res.json({ success: true });
  });

  app.get("/api/admin/tasks", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const r = await storage.db.query(
      `SELECT t.*, COUNT(DISTINCT ut.user_id)::int AS completion_count,
              COUNT(DISTINCT tv.user_id)::int AS view_count
       FROM tasks t
       LEFT JOIN user_tasks ut ON ut.task_id=t.id
       LEFT JOIN task_views tv ON tv.task_id=t.id
       GROUP BY t.id
       ORDER BY t.created_at DESC`
    );
    res.json({ tasks: r.rows });
  });

  app.post("/api/admin/tasks", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { title, url, category, reward } = req.body;
    const task = await storage.createTask({ title, url, category, reward });
    res.json({ task });
  });

  app.patch("/api/admin/tasks/:id", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { title, url, category, reward, isActive } = req.body;
    const r = await storage.db.query(
      `UPDATE tasks
       SET title=COALESCE($1,title), url=COALESCE($2,url),
           category=COALESCE($3,category), reward=COALESCE($4,reward),
           is_active=COALESCE($5,is_active)
       WHERE id=$6
       RETURNING *`,
      [title, url, category, reward, isActive, req.params.id]
    );
    if (!r.rows[0]) return res.status(404).json({ error: "Task not found" });
    res.json({ task: r.rows[0] });
  });

  app.delete("/api/admin/tasks/:id", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    await storage.deleteTask(parseInt(req.params.id));
    res.json({ success: true });
  });

  app.get("/api/admin/events", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const r = await storage.db.query("SELECT * FROM events ORDER BY created_at DESC");
    res.json({ events: r.rows });
  });

  app.post("/api/admin/events", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { title, type, reward, isActive } = req.body;
    const r = await storage.db.query(
      "INSERT INTO events (title, type, reward, is_active, start_date, end_date) VALUES ($1,$2,$3,$4,NOW(),NOW()+INTERVAL '30 days') RETURNING *",
      [title, type, reward, isActive]
    );
    res.json({ event: r.rows[0] });
  });

  app.put("/api/admin/events/:id", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { isActive } = req.body;
    await storage.db.query("UPDATE events SET is_active=$1 WHERE id=$2", [isActive, req.params.id]);
    res.json({ success: true });
  });

  // ======= ADMIN NOTIFICATIONS =======
  app.get("/api/admin/notifications", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const notifications = await storage.getAllNotifications();
    res.json({ notifications });
  });

  app.post("/api/admin/notifications", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { title, message, type } = req.body;
    if (!title || !message) return res.status(400).json({ error: "Title and message required" });
    const notification = await storage.createNotification({ title, message, type });
    res.json({ notification });
  });

  app.delete("/api/admin/notifications/:id", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    await storage.deleteNotification(parseInt(req.params.id));
    res.json({ success: true });
  });

  // ======= ADMIN SUPPORT =======
  app.get("/api/admin/support", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const messages = await storage.getAllSupportMessages();
    const queue = await storage.getSupportQueueStats();
    res.json({ messages, queue });
  });

  app.post("/api/admin/support/:id/reply", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { reply } = req.body;
    await storage.addSupportReply(parseInt(req.params.id), reply, false);
    res.json({ success: true });
  });

  app.post("/api/admin/support/:id/claim", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const message = await storage.claimSupportMessage(parseInt(req.params.id));
    if (!message) return res.status(400).json({ error: "Message is no longer waiting" });
    res.json({ message, queue: await storage.getSupportQueueStats() });
  });

  // ======= ADMIN PASSWORD RESETS =======
  app.get("/api/admin/password-resets", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const resets = await storage.getPendingPasswordResets();
    res.json({ resets });
  });

  // Admin: generate reset code for a specific user
  app.post("/api/admin/generate-reset-code", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: "Email required" });
    const user = await storage.getUserByEmail(email.toLowerCase());
    if (!user) return res.status(404).json({ error: "User not found" });
    const code = await storage.generateResetCode(email.toLowerCase());
    res.json({ code, email });
  });

  app.post("/api/admin/password-resets/:id/approve", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const reset = await storage.approvePasswordReset(parseInt(req.params.id));
    if (!reset) return res.status(400).json({ error: "Request is expired, used, or not found" });
    res.json({ reset });
  });

  // Admin: manually reset inactivity balances
  app.post("/api/admin/reset-inactive-balances", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const reset = await storage.resetInactiveBalances();
    res.json({ success: true, resetCount: reset.length, users: reset });
  });

  // Admin: update user password directly
  app.post("/api/admin/users/:id/set-password", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { newPassword } = req.body;
    if (!newPassword) return res.status(400).json({ error: "New password required" });
    await storage.db.query("UPDATE users SET password=$1 WHERE id=$2", [newPassword, req.params.id]);
    res.json({ success: true });
  });

  const httpServer = createServer(app);

  // ======= SCHEDULED: 7-day inactivity balance reset =======
  // Runs every hour to check and reset inactive users
  setInterval(async () => {
    try {
      await storage.resetInactiveBalances();
    } catch {}
  }, 60 * 60 * 1000); // every 1 hour

  return httpServer;
}

function sanitizeUser(user: Record<string, unknown>) {
  const { password, ...safe } = user;
  void password;
  return safe;
}

function isAdmin(req: Request): boolean {
  const token = req.headers["x-admin-token"] as string;
  if (!token) return false;
  const expiresAt = adminTokens.get(token);
  if (!expiresAt) return false;
  if (expiresAt <= Date.now()) {
    adminTokens.delete(token);
    return false;
  }
  return true;
}
