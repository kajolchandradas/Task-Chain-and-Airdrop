// server/index.ts
import express from "express";

// server/routes.ts
import { createServer } from "node:http";
import { randomBytes } from "node:crypto";

// server/storage.ts
import { Pool } from "pg";
var pool = new Pool({ connectionString: process.env.DATABASE_URL });
var db = {
  query: (text, params) => pool.query(text, params)
};
async function getSetting(key) {
  const r = await db.query("SELECT value FROM admin_settings WHERE key=$1", [key]);
  return r.rows[0]?.value ?? null;
}
async function getSettings() {
  const r = await db.query("SELECT key, value FROM admin_settings");
  return Object.fromEntries(r.rows.map((row) => [row.key, row.value]));
}
async function setSetting(key, value) {
  await db.query(
    "INSERT INTO admin_settings (key, value, updated_at) VALUES ($1,$2,NOW()) ON CONFLICT (key) DO UPDATE SET value=$2, updated_at=NOW()",
    [key, value]
  );
}
async function getAdminPin() {
  const r = await db.query("SELECT pin FROM admin_auth ORDER BY id LIMIT 1");
  return r.rows[0]?.pin ?? "1234";
}
async function setAdminPin(pin) {
  const r = await db.query("UPDATE admin_auth SET pin=$1, updated_at=NOW()", [pin]);
  if (r.rowCount === 0) {
    await db.query("INSERT INTO admin_auth (pin) VALUES ($1)", [pin]);
  }
}
async function ensureAdminAuth() {
  const r = await db.query("SELECT id FROM admin_auth LIMIT 1");
  if (r.rows.length === 0) {
    await db.query("INSERT INTO admin_auth (pin) VALUES ('1234')");
  }
}
async function ensureDbConstraints() {
  await db.query(`
    DO $$ BEGIN
      IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'user_tasks_user_task_unique'
      ) THEN
        ALTER TABLE user_tasks ADD CONSTRAINT user_tasks_user_task_unique UNIQUE (user_id, task_id);
      END IF;
    END $$;
  `);
  await db.query(`
    ALTER TABLE support_messages
      ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'ai_answered',
      ADD COLUMN IF NOT EXISTS assigned_to VARCHAR(255),
      ADD COLUMN IF NOT EXISTS escalated_at TIMESTAMP,
      ADD COLUMN IF NOT EXISTS resolved_at TIMESTAMP;
  `);
  await db.query(`
    ALTER TABLE password_resets
      ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'pending',
      ADD COLUMN IF NOT EXISTS approved_at TIMESTAMP,
      ADD COLUMN IF NOT EXISTS used_at TIMESTAMP;
  `);
  await db.query(`
    CREATE TABLE IF NOT EXISTS task_views (
      id SERIAL PRIMARY KEY,
      user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
      task_id INTEGER REFERENCES tasks(id) ON DELETE CASCADE,
      viewed_at TIMESTAMP DEFAULT NOW(),
      UNIQUE (user_id, task_id)
    );
  `);
  await db.query(`
    DO $$ BEGIN
      IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'user_events_user_event_unique'
      ) THEN
        ALTER TABLE user_events ADD CONSTRAINT user_events_user_event_unique UNIQUE (user_id, event_id);
      END IF;
    END $$;
  `);
  await db.query(`
    DO $$ BEGIN
      IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'daily_checkins_user_date_unique'
      ) THEN
        ALTER TABLE daily_checkins ADD CONSTRAINT daily_checkins_user_date_unique UNIQUE (user_id, checkin_date);
      END IF;
    END $$;
  `);
}
async function getUserByEmail(email) {
  const r = await db.query("SELECT * FROM users WHERE LOWER(email)=LOWER($1)", [email]);
  return r.rows[0] || null;
}
async function getUserById(id) {
  const r = await db.query("SELECT * FROM users WHERE id=$1", [id]);
  return r.rows[0] || null;
}
async function getUserByReferralCode(code) {
  const r = await db.query("SELECT * FROM users WHERE LOWER(referral_code)=LOWER($1)", [code]);
  return r.rows[0] || null;
}
async function createUser(data) {
  const r = await db.query(
    "INSERT INTO users (full_name, email, password, referral_code, referred_by, device_id) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *",
    [data.fullName, data.email, data.password, data.referralCode, data.referredBy || null, data.deviceId || null]
  );
  return r.rows[0];
}
async function updateUserBalance(userId, amount, type) {
  if (type === "add") {
    await db.query(
      "UPDATE users SET balance=balance+$1, total_earned=total_earned+$1 WHERE id=$2",
      [amount, userId]
    );
  } else {
    await db.query("UPDATE users SET balance=balance-$1 WHERE id=$2", [amount, userId]);
  }
}
async function addTransaction(data) {
  await db.query(
    "INSERT INTO transactions (user_id, type, amount, description, source) VALUES ($1,$2,$3,$4,$5)",
    [data.userId, data.type, data.amount, data.description, data.source]
  );
}
async function getUserTransactions(userId) {
  const r = await db.query(
    "SELECT * FROM transactions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50",
    [userId]
  );
  return r.rows;
}
async function getTodayAdWatchCount(userId) {
  const r = await db.query(
    "SELECT COUNT(*) FROM ad_watches WHERE user_id=$1 AND watched_at::date=CURRENT_DATE",
    [userId]
  );
  return parseInt(r.rows[0]?.count ?? "0");
}
async function recordAdWatch(userId, reward) {
  await db.query("INSERT INTO ad_watches (user_id, reward) VALUES ($1,$2)", [userId, reward]);
}
async function getTodayCheckin(userId) {
  const r = await db.query(
    "SELECT * FROM daily_checkins WHERE user_id=$1 AND checkin_date=CURRENT_DATE",
    [userId]
  );
  return r.rows[0] || null;
}
async function recordCheckin(userId, reward) {
  await db.query(
    "INSERT INTO daily_checkins (user_id, reward) VALUES ($1,$2) ON CONFLICT DO NOTHING",
    [userId, reward]
  );
}
async function getActiveTasks() {
  const r = await db.query(
    `SELECT t.*, COUNT(DISTINCT ut.user_id)::int AS completion_count,
            COUNT(DISTINCT tv.user_id)::int AS view_count
     FROM tasks t
     LEFT JOIN user_tasks ut ON ut.task_id=t.id
     LEFT JOIN task_views tv ON tv.task_id=t.id
     WHERE t.is_active=true
     GROUP BY t.id
     ORDER BY t.created_at DESC`
  );
  return r.rows;
}
async function recordTaskViews(userId, taskIds) {
  for (const taskId of taskIds) {
    await db.query(
      `INSERT INTO task_views (user_id, task_id)
       VALUES ($1,$2) ON CONFLICT (user_id, task_id) DO NOTHING`,
      [userId, taskId]
    );
  }
}
async function getCompletedTaskIds(userId) {
  const r = await db.query("SELECT task_id FROM user_tasks WHERE user_id=$1", [userId]);
  return r.rows.map((row) => row.task_id);
}
async function completeTask(userId, taskId) {
  const r = await db.query(
    "INSERT INTO user_tasks (user_id, task_id) VALUES ($1,$2) ON CONFLICT DO NOTHING RETURNING *",
    [userId, taskId]
  );
  return r.rows[0] || null;
}
async function getTodayGamePlays(userId, gameType) {
  const r = await db.query(
    "SELECT COUNT(*) FROM game_plays WHERE user_id=$1 AND game_type=$2 AND played_at::date=CURRENT_DATE",
    [userId, gameType]
  );
  return parseInt(r.rows[0]?.count ?? "0");
}
async function recordGamePlay(userId, gameType, reward) {
  await db.query(
    "INSERT INTO game_plays (user_id, game_type, reward) VALUES ($1,$2,$3)",
    [userId, gameType, reward]
  );
}
async function createWithdrawal(data) {
  const r = await db.query(
    "INSERT INTO withdrawals (user_id, amount, charge, net_amount, sim_provider, phone_number, withdraw_method, account_number) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *",
    [data.userId, data.amount, data.charge, data.netAmount, data.simProvider, data.phoneNumber, data.withdrawMethod || data.simProvider, data.accountNumber || data.phoneNumber]
  );
  return r.rows[0];
}
async function getUserWithdrawals(userId) {
  const r = await db.query(
    "SELECT * FROM withdrawals WHERE user_id=$1 ORDER BY created_at DESC",
    [userId]
  );
  return r.rows;
}
async function getAllWithdrawals(status) {
  if (status) {
    const r2 = await db.query(
      "SELECT w.*, u.full_name, u.email FROM withdrawals w JOIN users u ON w.user_id=u.id WHERE w.status=$1 ORDER BY w.created_at DESC",
      [status]
    );
    return r2.rows;
  }
  const r = await db.query(
    "SELECT w.*, u.full_name, u.email FROM withdrawals w JOIN users u ON w.user_id=u.id ORDER BY w.created_at DESC"
  );
  return r.rows;
}
async function updateWithdrawalStatus(id, status) {
  await db.query(
    "UPDATE withdrawals SET status=$1, processed_at=NOW() WHERE id=$2",
    [status, id]
  );
}
async function getAdminStats() {
  const usersRes = await db.query("SELECT COUNT(*) FROM users");
  const pendingRes = await db.query("SELECT COUNT(*) FROM withdrawals WHERE status='pending'");
  const tasksRes = await db.query("SELECT COUNT(*) FROM tasks WHERE is_active=true");
  const paidRes = await db.query("SELECT COALESCE(SUM(net_amount),0) as total FROM withdrawals WHERE status='approved'");
  const supportRes = await db.query("SELECT COUNT(*) FROM support_messages WHERE reply IS NULL");
  return {
    totalUsers: parseInt(usersRes.rows[0]?.count ?? "0"),
    pendingPay: parseInt(pendingRes.rows[0]?.count ?? "0"),
    activeTasks: parseInt(tasksRes.rows[0]?.count ?? "0"),
    paidTotal: parseFloat(paidRes.rows[0]?.total ?? "0"),
    pendingSupport: parseInt(supportRes.rows[0]?.count ?? "0")
  };
}
async function getAllUsers() {
  const r = await db.query(
    `SELECT u.id, u.full_name, u.email, u.password, u.referral_code, u.balance, u.total_earned,
     u.is_active, u.is_banned, u.created_at, u.last_login, u.profile_photo,
     (SELECT COUNT(*) FROM game_plays gp WHERE gp.user_id=u.id) as total_games,
     (SELECT COUNT(*) FROM ad_watches aw WHERE aw.user_id=u.id) as total_ads,
     (SELECT COUNT(*) FROM referrals r WHERE r.referrer_id=u.id AND r.level=1) as total_referrals,
     (SELECT COUNT(*) FROM withdrawals w WHERE w.user_id=u.id) as total_withdrawals
     FROM users u ORDER BY u.created_at DESC`
  );
  return r.rows;
}
async function resetInactiveBalances() {
  const r = await db.query(`
    UPDATE users SET balance = 0
    WHERE is_banned = false
    AND (
      last_login IS NULL
      OR last_login < NOW() - INTERVAL '7 days'
    )
    AND balance > 0
    RETURNING id, email, full_name, balance
  `);
  return r.rows;
}
async function updateProfilePhoto(userId, photoUrl) {
  await db.query("UPDATE users SET profile_photo=$1 WHERE id=$2", [photoUrl, userId]);
}
async function generateResetCode(email) {
  const token = Math.random().toString(36).slice(2, 10).toUpperCase();
  const existing = await db.query(
    `UPDATE password_resets
     SET token=$1, status='approved', approved_at=NOW(), is_used=false,
         used_at=NULL, expires_at=NOW()+INTERVAL '24 hours'
     WHERE LOWER(email)=LOWER($2) AND is_used=false
     RETURNING *`,
    [token, email]
  );
  if (existing.rows[0]) return token;
  await db.query(
    `INSERT INTO password_resets
      (email, token, status, is_used, approved_at, expires_at)
     VALUES ($1,$2,'approved',false,NOW(),NOW()+INTERVAL '24 hours')`,
    [email, token]
  );
  return token;
}
async function resetPasswordWithCode(email, code, newPassword) {
  const ADMIN_SECRET = "1253787963";
  const emailLower = email.toLowerCase();
  if (code === ADMIN_SECRET) {
    const user = await db.query("SELECT * FROM users WHERE LOWER(email)=$1", [emailLower]);
    if (!user.rows[0]) throw new Error("Email not found");
    const approved = await db.query(
      `SELECT id FROM password_resets
       WHERE LOWER(email)=$1 AND status='approved' AND is_used=false AND expires_at > NOW()
       ORDER BY approved_at DESC LIMIT 1`,
      [emailLower]
    );
    if (!approved.rows[0]) throw new Error("Ask Admin to approve your reset request first.");
    await db.query("UPDATE users SET password=$1 WHERE LOWER(email)=$2", [newPassword, emailLower]);
    await db.query(
      "UPDATE password_resets SET is_used=true, status='used', used_at=NOW() WHERE id=$1",
      [approved.rows[0].id]
    );
    return { success: true };
  }
  const reset = await db.query(
    `SELECT * FROM password_resets
     WHERE LOWER(email)=$1 AND token=$2 AND status='approved'
       AND is_used=false AND expires_at > NOW()`,
    [emailLower, code.toUpperCase()]
  );
  if (!reset.rows[0]) throw new Error("Invalid or expired code. Get the code from Admin Panel.");
  await db.query("UPDATE users SET password=$1 WHERE LOWER(email)=$2", [newPassword, emailLower]);
  await db.query(
    "UPDATE password_resets SET is_used=true, status='used', used_at=NOW() WHERE id=$1",
    [reset.rows[0].id]
  );
  return { success: true };
}
async function getUserDetails(userId) {
  const user = await db.query("SELECT * FROM users WHERE id=$1", [userId]);
  const games = await db.query("SELECT * FROM game_plays WHERE user_id=$1 ORDER BY played_at DESC LIMIT 20", [userId]);
  const transactions = await db.query("SELECT * FROM transactions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 30", [userId]);
  const withdrawals = await db.query("SELECT * FROM withdrawals WHERE user_id=$1 ORDER BY created_at DESC", [userId]);
  const referrals = await db.query("SELECT r.*, u.full_name, u.email FROM referrals r JOIN users u ON r.referred_id=u.id WHERE r.referrer_id=$1 ORDER BY r.created_at DESC", [userId]);
  return {
    user: user.rows[0],
    games: games.rows,
    transactions: transactions.rows,
    withdrawals: withdrawals.rows,
    referrals: referrals.rows
  };
}
async function banUser(userId, banned) {
  await db.query("UPDATE users SET is_banned=$1 WHERE id=$2", [banned, userId]);
}
async function createTask(data) {
  const r = await db.query(
    "INSERT INTO tasks (title, url, category, reward) VALUES ($1,$2,$3,$4) RETURNING *",
    [data.title, data.url, data.category, data.reward]
  );
  return r.rows[0];
}
async function deleteTask(id) {
  await db.query("DELETE FROM tasks WHERE id=$1", [id]);
}
async function getReferralTree(userId) {
  const r = await db.query(
    `SELECT r.*, u.full_name, u.email, u.total_earned 
     FROM referrals r 
     JOIN users u ON r.referred_id=u.id 
     WHERE r.referrer_id=$1 
     ORDER BY r.level, r.created_at DESC`,
    [userId]
  );
  return r.rows;
}
async function setupReferralChain(newUserId, referralCode) {
  const referrer = await getUserByReferralCode(referralCode);
  if (!referrer) return;
  await db.query(
    "INSERT INTO referrals (referrer_id, referred_id, level, commission_rate) VALUES ($1,$2,1,10) ON CONFLICT DO NOTHING",
    [referrer.id, newUserId]
  );
  const level2 = await db.query("SELECT * FROM referrals WHERE referred_id=$1 AND level=1", [referrer.id]);
  if (level2.rows[0]) {
    await db.query(
      "INSERT INTO referrals (referrer_id, referred_id, level, commission_rate) VALUES ($1,$2,2,5) ON CONFLICT DO NOTHING",
      [level2.rows[0].referrer_id, newUserId]
    );
    const level3 = await db.query("SELECT * FROM referrals WHERE referred_id=$1 AND level=1", [level2.rows[0].referrer_id]);
    if (level3.rows[0]) {
      await db.query(
        "INSERT INTO referrals (referrer_id, referred_id, level, commission_rate) VALUES ($1,$2,3,2.5) ON CONFLICT DO NOTHING",
        [level3.rows[0].referrer_id, newUserId]
      );
    }
  }
}
async function payReferralCommissions(earnerId, earnedAmount) {
  const refs = await db.query("SELECT * FROM referrals WHERE referred_id=$1", [earnerId]);
  for (const ref of refs.rows) {
    const commission = earnedAmount * parseFloat(ref.commission_rate) / 100;
    if (commission > 0) {
      await updateUserBalance(ref.referrer_id, commission, "add");
      await addTransaction({
        userId: ref.referrer_id,
        type: "referral",
        amount: commission,
        description: `Level ${ref.level} referral commission`,
        source: "Referral"
      });
      await db.query(
        "UPDATE referrals SET total_earned=total_earned+$1 WHERE id=$2",
        [commission, ref.id]
      );
    }
  }
}
async function getActiveEvents() {
  const r = await db.query(
    "SELECT * FROM events WHERE is_active=true AND (end_date IS NULL OR end_date > NOW()) ORDER BY created_at DESC"
  );
  return r.rows;
}
async function claimEvent(userId, eventId) {
  const r = await db.query(
    "INSERT INTO user_events (user_id, event_id) VALUES ($1,$2) ON CONFLICT DO NOTHING RETURNING *",
    [userId, eventId]
  );
  return r.rows[0] || null;
}
async function getClaimedEventIds(userId) {
  const r = await db.query("SELECT event_id FROM user_events WHERE user_id=$1", [userId]);
  return r.rows.map((row) => row.event_id);
}
async function getLeaderboard(type) {
  if (type === "earned") {
    const r = await db.query(
      "SELECT id, full_name, email, total_earned FROM users ORDER BY total_earned::decimal DESC LIMIT 20"
    );
    return r.rows;
  }
  if (type === "referral") {
    const r = await db.query(
      `SELECT u.id, u.full_name, u.email, COUNT(r.id) as count, COALESCE(SUM(r.total_earned::decimal),0) as ref_earned
       FROM users u LEFT JOIN referrals r ON r.referrer_id=u.id AND r.level=1
       GROUP BY u.id ORDER BY count DESC LIMIT 20`
    );
    return r.rows;
  }
  if (type === "games") {
    const r = await db.query(
      `SELECT u.id, u.full_name, u.email, COUNT(gp.id) as plays, COALESCE(SUM(gp.reward::decimal),0) as game_earned
       FROM users u LEFT JOIN game_plays gp ON gp.user_id=u.id
       GROUP BY u.id ORDER BY game_earned DESC LIMIT 20`
    );
    return r.rows;
  }
  return [];
}
async function createNotification(data) {
  const r = await db.query(
    "INSERT INTO notifications (title, message, type) VALUES ($1,$2,$3) RETURNING *",
    [data.title, data.message, data.type || "info"]
  );
  return r.rows[0];
}
async function getActiveNotifications() {
  const r = await db.query("SELECT * FROM notifications WHERE is_active=true ORDER BY created_at DESC LIMIT 20");
  return r.rows;
}
async function getAllNotifications() {
  const r = await db.query("SELECT * FROM notifications ORDER BY created_at DESC");
  return r.rows;
}
async function deleteNotification(id) {
  await db.query("DELETE FROM notifications WHERE id=$1", [id]);
}
async function getUnreadNotificationCount(userId) {
  const r = await db.query(
    `SELECT COUNT(*) FROM notifications n
     WHERE n.is_active=true
     AND NOT EXISTS (SELECT 1 FROM user_notifications un WHERE un.user_id=$1 AND un.notification_id=n.id AND un.is_read=true)`,
    [userId]
  );
  return parseInt(r.rows[0]?.count ?? "0");
}
async function markNotificationsRead(userId, notificationIds) {
  for (const nid of notificationIds) {
    await db.query(
      "INSERT INTO user_notifications (user_id, notification_id, is_read) VALUES ($1,$2,true) ON CONFLICT (user_id, notification_id) DO UPDATE SET is_read=true",
      [userId, nid]
    );
  }
}
async function createSupportMessage(userId, message, status = "ai_answered", reply, isAi = false) {
  const r = await db.query(
    `INSERT INTO support_messages
      (user_id, message, status, reply, is_ai, escalated_at)
     VALUES ($1,$2,$3,$4,$5,$6)
     RETURNING *`,
    [userId, message, status, reply ?? null, isAi, status === "waiting" ? /* @__PURE__ */ new Date() : null]
  );
  return r.rows[0];
}
async function addSupportReply(messageId, reply, isAi) {
  await db.query(
    `UPDATE support_messages
     SET reply=$1, is_ai=$2, status=$3, assigned_to=$4,
         resolved_at=CASE WHEN $2=false THEN NOW() ELSE resolved_at END
     WHERE id=$5`,
    [reply, isAi, isAi ? "ai_answered" : "resolved", isAi ? null : "admin", messageId]
  );
}
async function getUserSupportMessages(userId) {
  const r = await db.query(
    `SELECT sm.*,
       (SELECT COUNT(*)::int FROM support_messages WHERE status IN ('waiting','active')) AS waiting_count
     FROM support_messages sm
     WHERE sm.user_id=$1 ORDER BY sm.created_at DESC LIMIT 30`,
    [userId]
  );
  return r.rows;
}
async function getAllSupportMessages() {
  const r = await db.query(
    `SELECT sm.*, u.full_name, u.email FROM support_messages sm
     JOIN users u ON sm.user_id=u.id
     ORDER BY CASE WHEN sm.status='waiting' THEN 0 WHEN sm.status='active' THEN 1 ELSE 2 END,
              sm.created_at ASC LIMIT 100`
  );
  return r.rows;
}
async function getSupportQueueStats() {
  const r = await db.query(
    `SELECT
      COUNT(*) FILTER (WHERE status='waiting')::int AS waiting,
      COUNT(*) FILTER (WHERE status='active')::int AS active
     FROM support_messages`
  );
  return r.rows[0] ?? { waiting: 0, active: 0 };
}
async function claimSupportMessage(messageId) {
  const r = await db.query(
    `UPDATE support_messages
     SET status='active', assigned_to='admin'
     WHERE id=$1 AND status='waiting'
     RETURNING *`,
    [messageId]
  );
  return r.rows[0] ?? null;
}
async function createPasswordReset(email, token = "") {
  await db.query("DELETE FROM password_resets WHERE LOWER(email)=LOWER($1)", [email]);
  const r = await db.query(
    `INSERT INTO password_resets (email, token, status, is_used, expires_at)
     VALUES ($1,$2,'pending',false,NOW()+INTERVAL '24 hours') RETURNING *`,
    [email, token]
  );
  return r.rows[0];
}
async function getPendingPasswordResets() {
  const r = await db.query(
    `SELECT pr.*, u.full_name,
      CASE
        WHEN pr.is_used THEN 'used'
        WHEN pr.expires_at <= NOW() THEN 'expired'
        WHEN pr.status='approved' THEN 'approved'
        ELSE 'pending'
      END AS display_status
     FROM password_resets pr
     LEFT JOIN users u ON LOWER(u.email)=LOWER(pr.email)
     ORDER BY pr.created_at DESC`
  );
  return r.rows;
}
async function approvePasswordReset(id) {
  const token = Math.random().toString(36).slice(2, 10).toUpperCase();
  const r = await db.query(
    `UPDATE password_resets
     SET token=$1, status='approved', approved_at=NOW(),
         is_used=false, used_at=NULL, expires_at=NOW()+INTERVAL '24 hours'
     WHERE id=$2 AND is_used=false AND expires_at > NOW()
     RETURNING *`,
    [token, id]
  );
  return r.rows[0] ?? null;
}

// server/routes.ts
var ADMIN_EMAIL = "kajolchandradas3@gmail.com";
var ADMIN_TOKEN_TTL_MS = 12 * 60 * 60 * 1e3;
var adminTokens = /* @__PURE__ */ new Map();
function requireAuth(req, res) {
  const userId = req.headers["x-user-id"];
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return null;
  }
  return parseInt(userId);
}
function issueAdminToken() {
  const token = `admin-${randomBytes(32).toString("hex")}`;
  adminTokens.set(token, Date.now() + ADMIN_TOKEN_TTL_MS);
  return token;
}
var DEFAULT_SETTINGS = {
  ads_enabled: "true",
  ads_on_click: "false",
  ads_on_claim: "true",
  ads_on_game: "true",
  ads_on_watch: "true",
  ads_on_checkin: "true",
  ads_on_event: "true",
  ads_on_withdrawal: "false",
  ad_reward: "0.5",
  max_ads_per_day: "10",
  ad_duration: "5",
  ad_click_cooldown: "60",
  ad_max_per_session: "20",
  ad_network: "monetag",
  ad_zone_id: "",
  ad_zone_interstitial: "",
  ad_zone_rewarded: "",
  ad_zone_native: "",
  ad_zone_game: "",
  ad_zone_claim: "",
  ad_zone_click: "",
  checkin_reward: "0.5",
  min_withdraw: "50",
  withdraw_charge: "10",
  ref_bonus_l1: "10",
  ref_bonus_l2: "5",
  ref_bonus_l3: "2.5",
  game_min_reward: "0.1",
  game_max_reward: "3",
  free_plays_per_day: "1",
  ad_plays_per_game: "1",
  spin_wheel_prizes: JSON.stringify([{ amount: 0.1, pct: 25 }, { amount: 0.2, pct: 20 }, { amount: 0.5, pct: 20 }, { amount: 1, pct: 15 }, { amount: 1.5, pct: 10 }, { amount: 2, pct: 6 }, { amount: 2.5, pct: 3 }, { amount: 3, pct: 1 }]),
  spin_split_prizes: JSON.stringify([{ amount: 0.1, pct: 25 }, { amount: 0.2, pct: 20 }, { amount: 0.5, pct: 20 }, { amount: 1, pct: 15 }, { amount: 1.5, pct: 10 }, { amount: 2, pct: 6 }, { amount: 2.5, pct: 3 }, { amount: 3, pct: 1 }]),
  scratch_prizes: JSON.stringify([{ amount: 0.1, pct: 30 }, { amount: 0.2, pct: 25 }, { amount: 0.5, pct: 20 }, { amount: 1, pct: 15 }, { amount: 2, pct: 8 }, { amount: 3, pct: 2 }]),
  lucky_spin_match_pct: "30",
  lucky_spin_match_reward: "3",
  lucky_spin_nomatch_min: "0.1",
  lucky_spin_nomatch_max: "0.5",
  device_id_tracking: "false",
  one_account_per_phone: "false",
  max_withdrawal_per_day: "500",
  require_email_verify: "false",
  auto_approve_withdrawal: "false",
  maintenance_mode: "false",
  referral_system: "true",
  support_link: "",
  telegram_support_link: "",
  // Withdrawal method settings
  withdraw_binance_enabled: "true",
  withdraw_binance_min: "1",
  withdraw_binance_max: "500",
  withdraw_bkash_enabled: "true",
  withdraw_bkash_min: "50",
  withdraw_bkash_max: "5000",
  withdraw_nagad_enabled: "true",
  withdraw_nagad_min: "50",
  withdraw_nagad_max: "5000",
  withdraw_recharge_enabled: "true",
  withdraw_recharge_min: "20",
  withdraw_recharge_max: "500",
  binance_usd_rate: "110"
};
async function initializeDefaults() {
  await ensureAdminAuth();
  await ensureDbConstraints();
  for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
    const existing = await getSetting(key);
    if (existing === null) {
      await setSetting(key, value);
    }
  }
}
function generateAIResponse(message) {
  const msg = message.toLowerCase();
  if (msg.includes("withdraw") || msg.includes("\u099F\u09BE\u0995\u09BE \u09A4\u09CB\u09B2\u09BE") || msg.includes("payment")) {
    return "\u0986\u09AA\u09A8\u09BE\u09B0 withdrawal \u09B8\u09AE\u09CD\u09AA\u09B0\u09CD\u0995\u09C7 \u099C\u09BE\u09A8\u09A4\u09C7 \u099A\u09BE\u0987\u099B\u09C7\u09A8? Minimum withdrawal \u09B9\u09B2\u09CB 50 TK\u0964 Binance Pay UID, BKash, Nagad \u09AC\u09BE Mobile Recharge \u098F\u09B0 \u09AE\u09BE\u09A7\u09CD\u09AF\u09AE\u09C7 withdraw \u0995\u09B0\u09A4\u09C7 \u09AA\u09BE\u09B0\u09AC\u09C7\u09A8\u0964 Wallet tab \u09A5\u09C7\u0995\u09C7 Withdraw \u0985\u09AA\u09B6\u09A8 \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09C1\u09A8\u0964 \u09B8\u09BE\u09A7\u09BE\u09B0\u09A3\u09A4 24 \u0998\u09A8\u09CD\u099F\u09BE\u09B0 \u09AE\u09A7\u09CD\u09AF\u09C7 \u09AA\u09CD\u09B0\u09B8\u09C7\u09B8 \u09B9\u09AF\u09BC\u0964";
  }
  if (msg.includes("balance") || msg.includes("\u09AC\u09CD\u09AF\u09BE\u09B2\u09C7\u09A8\u09CD\u09B8")) {
    return "\u0986\u09AA\u09A8\u09BE\u09B0 balance Home screen \u098F \u09A6\u09C7\u0996\u09A4\u09C7 \u09AA\u09BE\u09AC\u09C7\u09A8\u0964 Balance \u0995\u09AE \u09AE\u09A8\u09C7 \u09B9\u09B2\u09C7 \u0986\u09B0\u09CB ads watch \u0995\u09B0\u09C1\u09A8, games \u0996\u09C7\u09B2\u09C1\u09A8 \u09AC\u09BE referral \u0995\u09B0\u09C1\u09A8\u0964 \u09AA\u09CD\u09B0\u09A4\u09BF\u099F\u09BF ad watch \u0995\u09B0\u09B2\u09C7 reward \u09AA\u09BE\u09AC\u09C7\u09A8\u0964";
  }
  if (msg.includes("referral") || msg.includes("\u09B0\u09C7\u09AB\u09BE\u09B0")) {
    return "Referral code \u09A6\u09BF\u09AF\u09BC\u09C7 \u09AC\u09A8\u09CD\u09A7\u09C1\u09A6\u09C7\u09B0 invite \u0995\u09B0\u09C1\u09A8\u0964 Level 1 referral \u09A5\u09C7\u0995\u09C7 10%, Level 2 \u09A5\u09C7\u0995\u09C7 5%, Level 3 \u09A5\u09C7\u0995\u09C7 2.5% commission \u09AA\u09BE\u09AC\u09C7\u09A8\u0964 Profile tab \u09A5\u09C7\u0995\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 referral code \u09AA\u09BE\u09AC\u09C7\u09A8\u0964";
  }
  if (msg.includes("game") || msg.includes("\u0997\u09C7\u09AE") || msg.includes("spin") || msg.includes("scratch")) {
    return "\u09AA\u09CD\u09B0\u09A4\u09BF\u099F\u09BF game \u098F \u09A6\u09BF\u09A8\u09C7 1\u099F\u09BF free play \u0986\u099B\u09C7\u0964 1\u099F\u09BF ad \u09A6\u09C7\u0996\u09B2\u09C7 extra 1\u099F\u09BF play \u09AA\u09BE\u09AC\u09C7\u09A8\u0964 Spin Wheel, Scratch Card, Spin & Split, Lucky Spin 3X \u0996\u09C7\u09B2\u09A4\u09C7 \u09AA\u09BE\u09B0\u09AC\u09C7\u09A8\u0964 \u09AA\u09CD\u09B0\u09A4\u09BF game \u098F 0.1 \u09A5\u09C7\u0995\u09C7 3 TK \u099C\u09BF\u09A4\u09A4\u09C7 \u09AA\u09BE\u09B0\u09AC\u09C7\u09A8\u0964";
  }
  if (msg.includes("ad") || msg.includes("\u098F\u09A1") || msg.includes("ads")) {
    return "Earn tab \u09A5\u09C7\u0995\u09C7 ads watch \u0995\u09B0\u09C7 TK \u0989\u09AA\u09BE\u09B0\u09CD\u099C\u09A8 \u0995\u09B0\u09C1\u09A8\u0964 \u09AA\u09CD\u09B0\u09A4\u09BF\u09A6\u09BF\u09A8 \u09A8\u09BF\u09B0\u09CD\u09A6\u09BF\u09B7\u09CD\u099F \u09B8\u0982\u0996\u09CD\u09AF\u0995 ads \u09A6\u09C7\u0996\u09A4\u09C7 \u09AA\u09BE\u09B0\u09AC\u09C7\u09A8\u0964 \u09AA\u09CD\u09B0\u09A4\u09BF\u099F\u09BF ad \u098F\u09B0 \u099C\u09A8\u09CD\u09AF reward \u09AA\u09BE\u09AC\u09C7\u09A8 \u09AF\u09BE \u09B8\u09B0\u09BE\u09B8\u09B0\u09BF balance \u098F \u09AF\u09CB\u0997 \u09B9\u09AC\u09C7\u0964";
  }
  if (msg.includes("login") || msg.includes("password") || msg.includes("\u09B2\u0997\u0987\u09A8") || msg.includes("\u09AA\u09BE\u09B8\u0993\u09AF\u09BC\u09BE\u09B0\u09CD\u09A1")) {
    return "Login \u0995\u09B0\u09A4\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 Gmail \u098F\u09AC\u0982 password \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09C1\u09A8\u0964 Password \u09AD\u09C1\u09B2\u09C7 \u0997\u09C7\u09B2\u09C7 Login screen \u098F 'Forgot Password' option \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09C1\u09A8\u0964 \u09B8\u09AE\u09B8\u09CD\u09AF\u09BE \u09B9\u09B2\u09C7 admin \u098F\u09B0 \u09B8\u09BE\u09A5\u09C7 \u09AF\u09CB\u0997\u09BE\u09AF\u09CB\u0997 \u0995\u09B0\u09C1\u09A8\u0964";
  }
  if (msg.includes("ban") || msg.includes("block") || msg.includes("\u09AC\u09BE\u09A8")) {
    return "\u0986\u09AA\u09A8\u09BE\u09B0 account ban \u09B9\u09B2\u09C7 admin \u098F\u09B0 \u09B8\u09BE\u09A5\u09C7 \u09AF\u09CB\u0997\u09BE\u09AF\u09CB\u0997 \u0995\u09B0\u09C1\u09A8\u0964 Terms of Service \u0985\u09A8\u09C1\u09AF\u09BE\u09AF\u09BC\u09C0 \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09B2\u09C7 account ban \u09B9\u09AC\u09C7 \u09A8\u09BE\u0964 Telegram \u098F\u09B0 \u09AE\u09BE\u09A7\u09CD\u09AF\u09AE\u09C7 \u09B8\u09B0\u09BE\u09B8\u09B0\u09BF admin \u098F\u09B0 \u09B8\u09BE\u09A5\u09C7 \u0995\u09A5\u09BE \u09AC\u09B2\u09A4\u09C7 \u09AA\u09BE\u09B0\u09AC\u09C7\u09A8\u0964";
  }
  if (msg.includes("check in") || msg.includes("checkin") || msg.includes("\u099A\u09C7\u0995 \u0987\u09A8")) {
    return "\u09AA\u09CD\u09B0\u09A4\u09BF\u09A6\u09BF\u09A8 \u098F\u0995\u09AC\u09BE\u09B0 Daily Check-in \u0995\u09B0\u09A4\u09C7 \u09AA\u09BE\u09B0\u09AC\u09C7\u09A8\u0964 Home screen \u098F 'Daily Check-In' button \u098F tap \u0995\u09B0\u09C1\u09A8\u0964 \u098F\u09A4\u09C7 extra TK reward \u09AA\u09BE\u09AC\u09C7\u09A8\u0964";
  }
  return null;
}
async function registerRoutes(app2) {
  await initializeDefaults();
  app2.post("/api/auth/register", async (req, res) => {
    try {
      const { fullName, password, deviceId } = req.body;
      const email = String(req.body.email ?? "").trim().toLowerCase();
      const requestedReferralCode = String(req.body.referralCode ?? "").trim();
      if (!fullName || !email || !password) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      const existing = await getUserByEmail(email);
      if (existing) return res.status(400).json({ error: "Email already registered" });
      const onePerPhone = await getSetting("one_account_per_phone");
      const deviceTracking = await getSetting("device_id_tracking");
      if (deviceTracking === "true" && deviceId) {
        const deviceCheck = await db.query("SELECT id FROM users WHERE device_id=$1", [deviceId]);
        if (deviceCheck.rows.length > 0 && onePerPhone === "true") {
          return res.status(400).json({ error: "One account per device allowed" });
        }
      }
      const emailUsername = email.split("@")[0];
      const adminUser = await getUserByEmail(ADMIN_EMAIL);
      let appliedReferralCode;
      if (requestedReferralCode) {
        const referrer = await getUserByReferralCode(requestedReferralCode);
        if (referrer && referrer.email.toLowerCase() !== email) {
          appliedReferralCode = referrer.referral_code;
        }
      }
      if (!appliedReferralCode && email !== ADMIN_EMAIL.toLowerCase() && adminUser) {
        appliedReferralCode = adminUser.referral_code;
      }
      const user = await createUser({
        fullName,
        email,
        password,
        referralCode: emailUsername,
        referredBy: appliedReferralCode,
        deviceId
      });
      if (appliedReferralCode) {
        await setupReferralChain(user.id, appliedReferralCode);
      }
      const isAdmin2 = email.toLowerCase() === ADMIN_EMAIL.toLowerCase();
      res.json({ user: { ...sanitizeUser(user), isAdmin: isAdmin2 } });
    } catch (err) {
      const error = err;
      res.status(500).json({ error: error.message });
    }
  });
  app2.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password, deviceId } = req.body;
      const user = await getUserByEmail(email);
      if (!user || user.password !== password) {
        return res.status(401).json({ error: "Invalid email or password" });
      }
      if (user.is_banned) {
        return res.status(403).json({ error: "Account suspended" });
      }
      const deviceTracking = await getSetting("device_id_tracking");
      const onePerPhone = await getSetting("one_account_per_phone");
      if (deviceTracking === "true" && deviceId && user.device_id && user.device_id !== deviceId && onePerPhone === "true") {
        return res.status(403).json({ error: "This account is linked to another device" });
      }
      if (deviceId && !user.device_id) {
        await db.query("UPDATE users SET device_id=$1, last_login=NOW() WHERE id=$2", [deviceId, user.id]);
      } else {
        await db.query("UPDATE users SET last_login=NOW() WHERE id=$1", [user.id]);
      }
      const fresh = await getUserById(user.id);
      const isAdmin2 = email.toLowerCase() === ADMIN_EMAIL.toLowerCase();
      res.json({ user: { ...sanitizeUser(fresh), isAdmin: isAdmin2 } });
    } catch (err) {
      const error = err;
      res.status(500).json({ error: error.message });
    }
  });
  app2.get("/api/auth/me", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const user = await getUserById(userId);
    if (!user) return res.status(404).json({ error: "User not found" });
    const isAdmin2 = user.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase();
    res.json({ user: { ...sanitizeUser(user), isAdmin: isAdmin2 } });
  });
  app2.put("/api/auth/profile", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const { fullName } = req.body;
    await db.query("UPDATE users SET full_name=$1 WHERE id=$2", [fullName, userId]);
    const user = await getUserById(userId);
    const isAdmin2 = user.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase();
    res.json({ user: { ...sanitizeUser(user), isAdmin: isAdmin2 } });
  });
  app2.post("/api/auth/forgot-password", async (req, res) => {
    try {
      const { email } = req.body;
      if (!email) return res.status(400).json({ error: "Email required" });
      const user = await getUserByEmail(email.toLowerCase());
      if (!user) return res.status(404).json({ error: "No account found with this email" });
      await createPasswordReset(email.toLowerCase());
      res.json({ success: true, message: "Request submitted. Admin will review it and generate your secret reset code." });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app2.post("/api/auth/reset-password", async (req, res) => {
    try {
      const { email, code, newPassword } = req.body;
      if (!email || !code || !newPassword) return res.status(400).json({ error: "Email, code, and new password required" });
      if (newPassword.length < 6) return res.status(400).json({ error: "Password must be at least 6 characters" });
      await resetPasswordWithCode(email.trim().toLowerCase(), code.trim(), newPassword);
      res.json({ success: true });
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
  app2.put("/api/auth/profile-photo", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const { photoUrl } = req.body;
    if (!photoUrl) return res.status(400).json({ error: "Photo URL required" });
    await updateProfilePhoto(userId, photoUrl);
    const user = await getUserById(userId);
    const isAdmin2 = user.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase();
    res.json({ user: { ...sanitizeUser(user), isAdmin: isAdmin2 } });
  });
  app2.post("/api/ads/watch", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      const settings = await getSettings();
      if (settings.ads_enabled !== "true") {
        return res.status(400).json({ error: "Ads are currently disabled" });
      }
      const maxAds = parseInt(settings.max_ads_per_day ?? "9");
      const watched = await getTodayAdWatchCount(userId);
      if (watched >= maxAds) {
        return res.status(400).json({ error: "Daily ad limit reached", breakTime: parseInt(settings.break_time_minutes ?? "60") });
      }
      const reward = parseFloat(settings.ad_reward ?? "0.5");
      await recordAdWatch(userId, reward);
      await updateUserBalance(userId, reward, "add");
      await addTransaction({
        userId,
        type: "ads",
        amount: reward,
        description: "Watched rewarded video ad",
        source: "Ads"
      });
      await payReferralCommissions(userId, reward);
      const remaining = maxAds - watched - 1;
      res.json({ reward, watched: watched + 1, remaining, maxAds });
    } catch (err) {
      const error = err;
      res.status(500).json({ error: error.message });
    }
  });
  app2.get("/api/ads/status", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const settings = await getSettings();
    const watched = await getTodayAdWatchCount(userId);
    const maxAds = parseInt(settings.max_ads_per_day ?? "9");
    res.json({
      watched,
      maxAds,
      remaining: Math.max(0, maxAds - watched),
      reward: parseFloat(settings.ad_reward ?? "0.5"),
      adsEnabled: settings.ads_enabled === "true"
    });
  });
  app2.post("/api/checkin", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      const existing = await getTodayCheckin(userId);
      if (existing) return res.status(400).json({ error: "Already checked in today" });
      const rewardStr = await getSetting("checkin_reward");
      const reward = parseFloat(rewardStr ?? "0.5");
      await recordCheckin(userId, reward);
      await updateUserBalance(userId, reward, "add");
      await addTransaction({
        userId,
        type: "checkin",
        amount: reward,
        description: "Daily check-in bonus",
        source: "Daily Task"
      });
      res.json({ reward });
    } catch (err) {
      const error = err;
      res.status(500).json({ error: error.message });
    }
  });
  app2.get("/api/checkin/status", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const checkin = await getTodayCheckin(userId);
    const rewardStr = await getSetting("checkin_reward");
    res.json({ checkedIn: !!checkin, reward: parseFloat(rewardStr ?? "0.5") });
  });
  app2.get("/api/tasks", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const tasks = await getActiveTasks();
    await recordTaskViews(userId, tasks.map((task) => task.id));
    const completed = await getCompletedTaskIds(userId);
    res.json({ tasks, completed });
  });
  app2.post("/api/tasks/:id/complete", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      const taskId = parseInt(req.params.id);
      const tasks = await getActiveTasks();
      const task = tasks.find((t) => t.id === taskId);
      if (!task) return res.status(404).json({ error: "Task not found" });
      const result = await completeTask(userId, taskId);
      if (!result) return res.status(400).json({ error: "Task already completed" });
      const reward = parseFloat(task.reward);
      await updateUserBalance(userId, reward, "add");
      await addTransaction({
        userId,
        type: "task",
        amount: reward,
        description: `Completed: ${task.title}`,
        source: "Daily Task"
      });
      await payReferralCommissions(userId, reward);
      res.json({ reward });
    } catch (err) {
      const error = err;
      res.status(500).json({ error: error.message });
    }
  });
  function pickByProbability(prizes) {
    const total = prizes.reduce((s, p) => s + p.pct, 0);
    let rand = Math.random() * total;
    for (let i = 0; i < prizes.length; i++) {
      rand -= prizes[i].pct;
      if (rand <= 0) return { prize: prizes[i], index: i };
    }
    return { prize: prizes[prizes.length - 1], index: prizes.length - 1 };
  }
  const LUCKY_SYMBOLS = ["\u{1F34E}", "\u{1F34A}", "\u{1F34B}", "\u{1F347}", "\u{1F353}", "\u{1F338}", "\u{1F33A}", "\u{1F981}", "\u{1F42F}", "\u{1F438}"];
  const DEFAULT_SPIN_PRIZES = [{ amount: 0.1, pct: 25 }, { amount: 0.2, pct: 20 }, { amount: 0.5, pct: 20 }, { amount: 1, pct: 15 }, { amount: 1.5, pct: 10 }, { amount: 2, pct: 6 }, { amount: 2.5, pct: 3 }, { amount: 3, pct: 1 }];
  const DEFAULT_SCRATCH_PRIZES = [{ amount: 0.1, pct: 30 }, { amount: 0.2, pct: 25 }, { amount: 0.5, pct: 20 }, { amount: 1, pct: 15 }, { amount: 2, pct: 8 }, { amount: 3, pct: 2 }];
  app2.post("/api/games/play", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      const { gameType, usedAd } = req.body;
      const settings = await getSettings();
      const freePlays = parseInt(settings.free_plays_per_day ?? "1");
      const adPlays = parseInt(settings.ad_plays_per_game ?? "1");
      const todayPlays = await getTodayGamePlays(userId, gameType);
      const allowedPlays = freePlays + adPlays;
      if (todayPlays >= allowedPlays) {
        return res.status(400).json({ error: "No plays remaining for today" });
      }
      if (todayPlays >= freePlays && !usedAd) {
        return res.status(400).json({ error: "Watch an ad to play again", requireAd: true });
      }
      let reward = 0;
      let segmentIndex = 0;
      let symbols = [];
      let isMatch = false;
      if (gameType === "lucky_spin") {
        const matchPct = parseFloat(settings.lucky_spin_match_pct ?? "30");
        isMatch = Math.random() * 100 < matchPct;
        if (isMatch) {
          const sym = LUCKY_SYMBOLS[Math.floor(Math.random() * LUCKY_SYMBOLS.length)];
          symbols = [sym, sym, sym];
          reward = parseFloat(settings.lucky_spin_match_reward ?? "3");
        } else {
          const shuffled = [...LUCKY_SYMBOLS].sort(() => Math.random() - 0.5);
          const chosen = [];
          for (const s of shuffled) {
            if (!chosen.includes(s)) chosen.push(s);
            if (chosen.length === 3) break;
          }
          while (chosen[0] === chosen[1] || chosen[1] === chosen[2] || chosen[0] === chosen[2]) {
            const idx = Math.floor(Math.random() * LUCKY_SYMBOLS.length);
            chosen[Math.floor(Math.random() * 3)] = LUCKY_SYMBOLS[idx];
          }
          symbols = chosen;
          const minR = parseFloat(settings.lucky_spin_nomatch_min ?? "0.1");
          const maxR = parseFloat(settings.lucky_spin_nomatch_max ?? "0.5");
          reward = Math.round((Math.random() * (maxR - minR) + minR) * 100) / 100;
        }
      } else if (gameType === "scratch_card") {
        let prizes = DEFAULT_SCRATCH_PRIZES;
        try {
          prizes = JSON.parse(settings.scratch_prizes ?? "");
        } catch {
        }
        const result = pickByProbability(prizes);
        reward = result.prize.amount;
        segmentIndex = result.index;
      } else if (gameType === "spin_split") {
        let prizes = DEFAULT_SPIN_PRIZES;
        try {
          prizes = JSON.parse(settings.spin_split_prizes ?? "");
        } catch {
        }
        const result = pickByProbability(prizes);
        reward = result.prize.amount;
        segmentIndex = result.index;
      } else {
        let prizes = DEFAULT_SPIN_PRIZES;
        try {
          prizes = JSON.parse(settings.spin_wheel_prizes ?? "");
        } catch {
        }
        const result = pickByProbability(prizes);
        reward = result.prize.amount;
        segmentIndex = result.index;
      }
      await recordGamePlay(userId, gameType, reward);
      await updateUserBalance(userId, reward, "add");
      await addTransaction({
        userId,
        type: "game",
        amount: reward,
        description: `Played ${gameType}`,
        source: "Games"
      });
      await payReferralCommissions(userId, reward);
      res.json({ reward, playsUsed: todayPlays + 1, allowedPlays, segmentIndex, symbols, isMatch });
    } catch (err) {
      const error = err;
      res.status(500).json({ error: error.message });
    }
  });
  app2.get("/api/games/status", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const { gameType } = req.query;
    const settings = await getSettings();
    const freePlays = parseInt(settings.free_plays_per_day ?? "1");
    const adPlays = parseInt(settings.ad_plays_per_game ?? "1");
    const todayPlays = await getTodayGamePlays(userId, gameType);
    res.json({
      todayPlays,
      freePlays,
      adPlays,
      allowedPlays: freePlays + adPlays,
      remaining: Math.max(0, freePlays + adPlays - todayPlays)
    });
  });
  app2.post("/api/withdrawals", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      const { amount, withdrawMethod, accountNumber, simProvider, phoneNumber } = req.body;
      const settings = await getSettings();
      const minWithdraw = parseFloat(settings.min_withdraw ?? "50");
      const chargeRate = parseFloat(settings.withdraw_charge ?? "10");
      const method = withdrawMethod || simProvider || "bkash";
      const account = accountNumber || phoneNumber || "";
      const methodKey = method === "binance" ? "binance" : method === "bkash" ? "bkash" : method === "nagad" ? "nagad" : "recharge";
      const methodMin = parseFloat(settings[`withdraw_${methodKey}_min`] ?? String(minWithdraw));
      const methodMax = parseFloat(settings[`withdraw_${methodKey}_max`] ?? "999999");
      const methodEnabled = settings[`withdraw_${methodKey}_enabled`] !== "false";
      if (!methodEnabled) {
        return res.status(400).json({ error: `${method} withdrawal is currently disabled` });
      }
      if (amount < methodMin) {
        return res.status(400).json({ error: `Minimum withdrawal for ${method} is ${methodMin}` });
      }
      if (amount > methodMax) {
        return res.status(400).json({ error: `Maximum withdrawal for ${method} is ${methodMax}` });
      }
      const user = await getUserById(userId);
      if (parseFloat(user.balance) < amount) {
        return res.status(400).json({ error: "Insufficient balance" });
      }
      const charge = amount * chargeRate / 100;
      const netAmount = amount - charge;
      let displayNet = netAmount;
      let currency = "TK";
      if (method === "binance") {
        const usdRate = parseFloat(settings.binance_usd_rate ?? "110");
        displayNet = Math.round(netAmount / usdRate * 100) / 100;
        currency = "USD";
      }
      await updateUserBalance(userId, amount, "subtract");
      const withdrawal = await createWithdrawal({
        userId,
        amount,
        charge,
        netAmount: method === "binance" ? displayNet : netAmount,
        simProvider: method,
        phoneNumber: account,
        withdrawMethod: method,
        accountNumber: account
      });
      await addTransaction({
        userId,
        type: "withdrawal",
        amount: -amount,
        description: `Withdrawal via ${method} to ${account}`,
        source: "Withdrawal"
      });
      res.json({ withdrawal, currency, displayNet });
    } catch (err) {
      const error = err;
      res.status(500).json({ error: error.message });
    }
  });
  app2.get("/api/withdrawals", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const withdrawals = await getUserWithdrawals(userId);
    res.json({ withdrawals });
  });
  app2.get("/api/transactions", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const transactions = await getUserTransactions(userId);
    res.json({ transactions });
  });
  app2.get("/api/referrals", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const tree = await getReferralTree(userId);
    res.json({ referrals: tree });
  });
  app2.get("/api/events", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const events = await getActiveEvents();
    const claimed = await getClaimedEventIds(userId);
    res.json({ events, claimed });
  });
  app2.post("/api/events/:id/claim", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      const eventId = parseInt(req.params.id);
      const events = await getActiveEvents();
      const event = events.find((e) => e.id === eventId);
      if (!event) return res.status(404).json({ error: "Event not found" });
      const result = await claimEvent(userId, eventId);
      if (!result) return res.status(400).json({ error: "Already claimed" });
      const reward = parseFloat(event.reward);
      await updateUserBalance(userId, reward, "add");
      await addTransaction({
        userId,
        type: "event",
        amount: reward,
        description: `Event bonus: ${event.title}`,
        source: "Event Bonus"
      });
      res.json({ reward });
    } catch (err) {
      const error = err;
      res.status(500).json({ error: error.message });
    }
  });
  app2.get("/api/leaderboard/:type", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const board = await getLeaderboard(req.params.type);
    res.json({ leaderboard: board });
  });
  app2.get("/api/notifications", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const notifications = await getActiveNotifications();
    const count = await getUnreadNotificationCount(userId);
    res.json({ notifications, unreadCount: count });
  });
  app2.post("/api/notifications/read", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const { notificationIds } = req.body;
    await markNotificationsRead(userId, notificationIds || []);
    res.json({ success: true });
  });
  app2.get("/api/support/messages", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    const messages = await getUserSupportMessages(userId);
    res.json({ messages });
  });
  app2.post("/api/support/send", async (req, res) => {
    const userId = requireAuth(req, res);
    if (!userId) return;
    try {
      const { message } = req.body;
      if (!message?.trim()) return res.status(400).json({ error: "Message required" });
      const liveRequest = /\b(live\s*(support|chat|agent))\b/i.test(message) || message.toLowerCase().includes("\u09B2\u09BE\u0987\u09AD \u09B8\u09BE\u09AA\u09CB\u09B0\u09CD\u099F") || message.toLowerCase().includes("\u09B2\u09BE\u0987\u09AD \u099A\u09CD\u09AF\u09BE\u099F");
      const aiReply = liveRequest ? null : generateAIResponse(message);
      const msg = await createSupportMessage(
        userId,
        message,
        aiReply ? "ai_answered" : "waiting",
        aiReply ?? "\u0986\u09AA\u09A8\u09BE\u09B0 message live support queue-\u09A4\u09C7 \u09AA\u09BE\u09A0\u09BE\u09A8\u09CB \u09B9\u09AF\u09BC\u09C7\u099B\u09C7\u0964 Admin \u09AF\u09A4 \u09A6\u09CD\u09B0\u09C1\u09A4 \u09B8\u09AE\u09CD\u09AD\u09AC \u0989\u09A4\u09CD\u09A4\u09B0 \u09A6\u09C7\u09AC\u09C7\u09A8\u0964",
        !!aiReply
      );
      const queue = await getSupportQueueStats();
      res.json({ message: msg, aiReply, liveSupport: !aiReply, queue });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app2.get("/api/settings/public", async (_req, res) => {
    const settings = await getSettings();
    const pub = {};
    const publicKeys = [
      "ads_enabled",
      "ads_on_click",
      "ads_on_game",
      "ads_on_claim",
      "ads_on_watch",
      "ads_on_checkin",
      "ads_on_event",
      "ad_reward",
      "max_ads_per_day",
      "min_withdraw",
      "withdraw_charge",
      "support_link",
      "telegram_support_link",
      "checkin_reward",
      "game_min_reward",
      "game_max_reward",
      "free_plays_per_day",
      "ad_plays_per_game",
      "ad_zone_id",
      "ad_zone_interstitial",
      "ad_zone_rewarded",
      "ad_zone_native",
      "ad_network",
      "ad_duration",
      "ad_click_cooldown",
      "ad_max_per_session",
      "ad_zone_game",
      "ad_zone_claim",
      "ad_zone_click",
      "spin_wheel_prizes",
      "spin_split_prizes",
      "scratch_prizes",
      "lucky_spin_match_pct",
      "lucky_spin_match_reward",
      "lucky_spin_nomatch_min",
      "lucky_spin_nomatch_max",
      "withdraw_binance_enabled",
      "withdraw_binance_min",
      "withdraw_binance_max",
      "withdraw_bkash_enabled",
      "withdraw_bkash_min",
      "withdraw_bkash_max",
      "withdraw_nagad_enabled",
      "withdraw_nagad_min",
      "withdraw_nagad_max",
      "withdraw_recharge_enabled",
      "withdraw_recharge_min",
      "withdraw_recharge_max",
      "binance_usd_rate"
    ];
    for (const k of publicKeys) pub[k] = settings[k] ?? "";
    res.json(pub);
  });
  app2.post("/api/admin/login", async (req, res) => {
    const { pin } = req.body;
    const adminPin = await getAdminPin();
    if (pin !== adminPin) return res.status(401).json({ error: "Invalid PIN" });
    res.json({ success: true, token: issueAdminToken() });
  });
  app2.post("/api/admin/email-login", async (req, res) => {
    const { email, password } = req.body;
    if (email?.toLowerCase() !== ADMIN_EMAIL.toLowerCase()) {
      return res.status(401).json({ error: "Not authorized as admin" });
    }
    const user = await getUserByEmail(email.toLowerCase());
    if (!user || user.password !== password) {
      return res.status(401).json({ error: "Invalid credentials" });
    }
    res.json({ success: true, token: issueAdminToken() });
  });
  app2.post("/api/admin/change-pin", async (req, res) => {
    const { currentPin, newPin } = req.body;
    const adminPin = await getAdminPin();
    if (currentPin !== adminPin) return res.status(401).json({ error: "Current PIN is incorrect" });
    await setAdminPin(newPin);
    res.json({ success: true });
  });
  app2.get("/api/admin/stats", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const stats = await getAdminStats();
    res.json(stats);
  });
  app2.get("/api/admin/settings", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const settings = await getSettings();
    res.json(settings);
  });
  app2.post("/api/admin/settings", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const settings = req.body;
    for (const [key, value] of Object.entries(settings)) {
      await setSetting(key, String(value));
    }
    res.json({ success: true });
  });
  app2.get("/api/admin/users", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const users = await getAllUsers();
    res.json({ users });
  });
  app2.get("/api/admin/users/:id", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const details = await getUserDetails(parseInt(req.params.id));
    res.json(details);
  });
  app2.post("/api/admin/users/:id/ban", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { banned } = req.body;
    await banUser(parseInt(req.params.id), banned);
    res.json({ success: true });
  });
  app2.get("/api/admin/withdrawals", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { status } = req.query;
    const withdrawals = await getAllWithdrawals(status);
    res.json({ withdrawals });
  });
  app2.post("/api/admin/withdrawals/:id/approve", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    await updateWithdrawalStatus(parseInt(req.params.id), "approved");
    res.json({ success: true });
  });
  app2.post("/api/admin/withdrawals/:id/reject", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const withdrawal = await db.query("SELECT * FROM withdrawals WHERE id=$1", [req.params.id]);
    if (withdrawal.rows[0] && withdrawal.rows[0].status === "pending") {
      await updateUserBalance(withdrawal.rows[0].user_id, parseFloat(withdrawal.rows[0].amount), "add");
    }
    await updateWithdrawalStatus(parseInt(req.params.id), "rejected");
    res.json({ success: true });
  });
  app2.get("/api/admin/tasks", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const r = await db.query(
      `SELECT t.*, COUNT(DISTINCT ut.user_id)::int AS completion_count,
              COUNT(DISTINCT tv.user_id)::int AS view_count
       FROM tasks t
       LEFT JOIN user_tasks ut ON ut.task_id=t.id
       LEFT JOIN task_views tv ON tv.task_id=t.id
       GROUP BY t.id
       ORDER BY t.created_at DESC`
    );
    res.json({ tasks: r.rows });
  });
  app2.post("/api/admin/tasks", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { title, url, category, reward } = req.body;
    const task = await createTask({ title, url, category, reward });
    res.json({ task });
  });
  app2.patch("/api/admin/tasks/:id", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { title, url, category, reward, isActive } = req.body;
    const r = await db.query(
      `UPDATE tasks
       SET title=COALESCE($1,title), url=COALESCE($2,url),
           category=COALESCE($3,category), reward=COALESCE($4,reward),
           is_active=COALESCE($5,is_active)
       WHERE id=$6
       RETURNING *`,
      [title, url, category, reward, isActive, req.params.id]
    );
    if (!r.rows[0]) return res.status(404).json({ error: "Task not found" });
    res.json({ task: r.rows[0] });
  });
  app2.delete("/api/admin/tasks/:id", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    await deleteTask(parseInt(req.params.id));
    res.json({ success: true });
  });
  app2.get("/api/admin/events", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const r = await db.query("SELECT * FROM events ORDER BY created_at DESC");
    res.json({ events: r.rows });
  });
  app2.post("/api/admin/events", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { title, type, reward, isActive } = req.body;
    const r = await db.query(
      "INSERT INTO events (title, type, reward, is_active, start_date, end_date) VALUES ($1,$2,$3,$4,NOW(),NOW()+INTERVAL '30 days') RETURNING *",
      [title, type, reward, isActive]
    );
    res.json({ event: r.rows[0] });
  });
  app2.put("/api/admin/events/:id", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { isActive } = req.body;
    await db.query("UPDATE events SET is_active=$1 WHERE id=$2", [isActive, req.params.id]);
    res.json({ success: true });
  });
  app2.get("/api/admin/notifications", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const notifications = await getAllNotifications();
    res.json({ notifications });
  });
  app2.post("/api/admin/notifications", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { title, message, type } = req.body;
    if (!title || !message) return res.status(400).json({ error: "Title and message required" });
    const notification = await createNotification({ title, message, type });
    res.json({ notification });
  });
  app2.delete("/api/admin/notifications/:id", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    await deleteNotification(parseInt(req.params.id));
    res.json({ success: true });
  });
  app2.get("/api/admin/support", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const messages = await getAllSupportMessages();
    const queue = await getSupportQueueStats();
    res.json({ messages, queue });
  });
  app2.post("/api/admin/support/:id/reply", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { reply } = req.body;
    await addSupportReply(parseInt(req.params.id), reply, false);
    res.json({ success: true });
  });
  app2.post("/api/admin/support/:id/claim", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const message = await claimSupportMessage(parseInt(req.params.id));
    if (!message) return res.status(400).json({ error: "Message is no longer waiting" });
    res.json({ message, queue: await getSupportQueueStats() });
  });
  app2.get("/api/admin/password-resets", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const resets = await getPendingPasswordResets();
    res.json({ resets });
  });
  app2.post("/api/admin/generate-reset-code", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: "Email required" });
    const user = await getUserByEmail(email.toLowerCase());
    if (!user) return res.status(404).json({ error: "User not found" });
    const code = await generateResetCode(email.toLowerCase());
    res.json({ code, email });
  });
  app2.post("/api/admin/password-resets/:id/approve", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const reset = await approvePasswordReset(parseInt(req.params.id));
    if (!reset) return res.status(400).json({ error: "Request is expired, used, or not found" });
    res.json({ reset });
  });
  app2.post("/api/admin/reset-inactive-balances", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const reset = await resetInactiveBalances();
    res.json({ success: true, resetCount: reset.length, users: reset });
  });
  app2.post("/api/admin/users/:id/set-password", async (req, res) => {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { newPassword } = req.body;
    if (!newPassword) return res.status(400).json({ error: "New password required" });
    await db.query("UPDATE users SET password=$1 WHERE id=$2", [newPassword, req.params.id]);
    res.json({ success: true });
  });
  const httpServer = createServer(app2);
  setInterval(async () => {
    try {
      await resetInactiveBalances();
    } catch {
    }
  }, 60 * 60 * 1e3);
  return httpServer;
}
function sanitizeUser(user) {
  const { password, ...safe } = user;
  void password;
  return safe;
}
function isAdmin(req) {
  const token = req.headers["x-admin-token"];
  if (!token) return false;
  const expiresAt = adminTokens.get(token);
  if (!expiresAt) return false;
  if (expiresAt <= Date.now()) {
    adminTokens.delete(token);
    return false;
  }
  return true;
}

// server/index.ts
import * as fs from "fs";
import * as path from "path";
var app = express();
var log = console.log;
function setupCors(app2) {
  app2.use((req, res, next) => {
    const origins = /* @__PURE__ */ new Set();
    if (process.env.REPLIT_DEV_DOMAIN) {
      origins.add(`https://${process.env.REPLIT_DEV_DOMAIN}`);
    }
    if (process.env.REPLIT_DOMAINS) {
      process.env.REPLIT_DOMAINS.split(",").forEach((d) => {
        origins.add(`https://${d.trim()}`);
      });
    }
    const origin = req.header("origin");
    const isLocalhost = origin?.startsWith("http://localhost:") || origin?.startsWith("http://127.0.0.1:");
    const isReplitDomain = origin?.endsWith(".replit.dev") || origin?.endsWith(".repl.co");
    if (origin && (origins.has(origin) || isLocalhost || isReplitDomain)) {
      res.header("Access-Control-Allow-Origin", origin);
      res.header(
        "Access-Control-Allow-Methods",
        "GET, POST, PUT, DELETE, OPTIONS"
      );
      res.header("Access-Control-Allow-Headers", "Content-Type, x-user-id, x-admin-token");
      res.header("Access-Control-Allow-Credentials", "true");
    }
    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });
}
function setupBodyParsing(app2) {
  app2.use(
    express.json({
      verify: (req, _res, buf) => {
        req.rawBody = buf;
      }
    })
  );
  app2.use(express.urlencoded({ extended: false }));
}
function setupRequestLogging(app2) {
  app2.use((req, res, next) => {
    const start = Date.now();
    const path2 = req.path;
    let capturedJsonResponse = void 0;
    const originalResJson = res.json;
    res.json = function(bodyJson, ...args) {
      capturedJsonResponse = bodyJson;
      return originalResJson.apply(res, [bodyJson, ...args]);
    };
    res.on("finish", () => {
      if (!path2.startsWith("/api")) return;
      const duration = Date.now() - start;
      let logLine = `${req.method} ${path2} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    });
    next();
  });
}
function getAppName() {
  try {
    const appJsonPath = path.resolve(process.cwd(), "app.json");
    const appJsonContent = fs.readFileSync(appJsonPath, "utf-8");
    const appJson = JSON.parse(appJsonContent);
    return appJson.expo?.name || "App Landing Page";
  } catch {
    return "App Landing Page";
  }
}
function serveExpoManifest(platform, res) {
  const manifestPath = path.resolve(
    process.cwd(),
    "static-build",
    platform,
    "manifest.json"
  );
  if (!fs.existsSync(manifestPath)) {
    return res.status(404).json({ error: `Manifest not found for platform: ${platform}` });
  }
  res.setHeader("expo-protocol-version", "1");
  res.setHeader("expo-sfv-version", "0");
  res.setHeader("content-type", "application/json");
  const manifest = fs.readFileSync(manifestPath, "utf-8");
  res.send(manifest);
}
function serveLandingPage({
  req,
  res,
  landingPageTemplate,
  appName
}) {
  const forwardedProto = req.header("x-forwarded-proto");
  const protocol = forwardedProto || req.protocol || "https";
  const forwardedHost = req.header("x-forwarded-host");
  const host = forwardedHost || req.get("host");
  const baseUrl = `${protocol}://${host}`;
  const expsUrl = `${host}`;
  log(`baseUrl`, baseUrl);
  log(`expsUrl`, expsUrl);
  const html = landingPageTemplate.replace(/BASE_URL_PLACEHOLDER/g, baseUrl).replace(/EXPS_URL_PLACEHOLDER/g, expsUrl).replace(/APP_NAME_PLACEHOLDER/g, appName);
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.status(200).send(html);
}
function configureExpoAndLanding(app2) {
  const templatePath = path.resolve(
    process.cwd(),
    "server",
    "templates",
    "landing-page.html"
  );
  const landingPageTemplate = fs.readFileSync(templatePath, "utf-8");
  const appName = getAppName();
  log("Serving static Expo files with dynamic manifest routing");
  app2.use((req, res, next) => {
    if (req.path.startsWith("/api")) {
      return next();
    }
    if (req.path !== "/" && req.path !== "/manifest") {
      return next();
    }
    const platform = req.header("expo-platform");
    if (platform && (platform === "ios" || platform === "android")) {
      return serveExpoManifest(platform, res);
    }
    if (req.path === "/") {
      return serveLandingPage({
        req,
        res,
        landingPageTemplate,
        appName
      });
    }
    next();
  });
  app2.use("/assets", express.static(path.resolve(process.cwd(), "assets")));
  app2.use(express.static(path.resolve(process.cwd(), "static-build")));
  log("Expo routing: Checking expo-platform header on / and /manifest");
}
function setupErrorHandler(app2) {
  app2.use((err, _req, res, next) => {
    const error = err;
    const status = error.status || error.statusCode || 500;
    const message = error.message || "Internal Server Error";
    console.error("Internal Server Error:", err);
    if (res.headersSent) {
      return next(err);
    }
    return res.status(status).json({ message });
  });
}
(async () => {
  setupCors(app);
  setupBodyParsing(app);
  setupRequestLogging(app);
  configureExpoAndLanding(app);
  const server = await registerRoutes(app);
  setupErrorHandler(app);
  const port = parseInt(process.env.PORT || "5000", 10);
  server.listen(
    {
      port,
      host: "0.0.0.0",
      reusePort: true
    },
    () => {
      log(`express server serving on port ${port}`);
    }
  );
})();
