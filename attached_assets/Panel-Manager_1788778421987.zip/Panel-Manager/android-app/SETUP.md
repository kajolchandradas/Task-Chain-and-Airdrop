# Earn Wallet Android App — Setup Guide

## Project Structure

```
android-app/
├── app/
│   ├── src/main/
│   │   ├── java/com/earnwallet/app/
│   │   │   └── MainActivity.kt          ← All app logic (single file)
│   │   ├── assets/
│   │   │   └── index.html               ← Local HTML content
│   │   ├── res/values/
│   │   │   └── strings.xml
│   │   └── AndroidManifest.xml
│   └── build.gradle                     ← App-level Gradle config
├── build.gradle                         ← Project-level Gradle config
├── settings.gradle
└── gradle.properties
```

## Steps to Open in Android Studio

1. Open Android Studio → **File → Open** → select the `android-app/` folder
2. Let Gradle sync finish
3. Connect a device or start an emulator
4. Click **Run ▶**

## Before Publishing — Replace Test AdMob IDs

In `MainActivity.kt`, replace:
```kotlin
private const val BANNER_AD_UNIT_ID       = "ca-app-pub-3940256099942544/6300978111"
private const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"
```

In `AndroidManifest.xml`, replace:
```xml
android:value="ca-app-pub-3940256099942544~3347511713"
```

With your **real** IDs from https://admob.google.com

## Key Features

| Feature | Details |
|---------|---------|
| WebView | Loads `assets/index.html`; JS enabled, DOM storage, file access |
| Internet check | Uses `NetworkCapabilities` (API 21+); shows offline screen if no connection |
| Retry button | Rechecks connectivity; reloads WebView on success |
| Banner ad | Bottom-anchored `AdSize.BANNER`; hidden if ad fails to load |
| Interstitial ad | Auto-shown every 120 seconds after page load; pre-loaded for smooth display |
| Back navigation | WebView history → back button → exit |

## Customisation

- **Change interstitial interval**: Edit `INTERSTITIAL_INTERVAL_SECONDS` in `MainActivity.kt`
- **Load a remote URL**: Replace `file:///android_asset/index.html` with your URL
- **Change app name**: Edit `android-app/app/src/main/res/values/strings.xml`
- **Change package name**: Rename `com.earnwallet.app` in `build.gradle` + `AndroidManifest.xml` + folder path

## Admin Login

Default Admin PIN for Earn Wallet app: **1234**
(Change from Admin Panel → Security → Change PIN)
