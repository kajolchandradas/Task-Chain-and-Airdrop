package com.earnwallet.app

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

// ─────────────────────────────────────────────────────────────────
//  CONFIGURATION  — Replace with your real AdMob IDs before release
// ─────────────────────────────────────────────────────────────────
private const val BANNER_AD_UNIT_ID      = "ca-app-pub-3940256099942544/6300978111"  // test banner
private const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712" // test interstitial

// How many seconds between interstitial auto-shows (0 = never auto-show)
private const val INTERSTITIAL_INTERVAL_SECONDS = 120L

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var bannerAdView: AdView
    private lateinit var offlineLayout: LinearLayout
    private lateinit var retryButton: Button
    private lateinit var offlineTitle: TextView
    private lateinit var offlineSubtitle: TextView

    private var interstitialAd: InterstitialAd? = null
    private val handler = Handler(Looper.getMainLooper())
    private var interstitialShownCount = 0

    // ── Lifecycle ────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialise AdMob SDK (non-blocking)
        MobileAds.initialize(this) {}

        buildLayout()
        loadInterstitialAd()

        if (isOnline()) {
            showWebView()
        } else {
            showOfflineScreen()
        }
    }

    override fun onResume() {
        super.onResume()
        bannerAdView.resume()
    }

    override fun onPause() {
        bannerAdView.pause()
        super.onPause()
    }

    override fun onDestroy() {
        bannerAdView.destroy()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    // ── Layout builder (programmatic — no XML required) ──────────

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildLayout() {
        // Root container: vertical LinearLayout
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(0xFF0F172A.toInt()) // dark bg
        }

        // ── WebView fills all available space above the banner ──
        webView = WebView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f // weight=1 → takes remaining height
            )
            configureWebView()
        }

        // ── Offline screen (same weight, hidden by default) ──────
        offlineLayout = buildOfflineLayout()

        // ── Banner ad anchored at bottom ─────────────────────────
        bannerAdView = AdView(this).apply {
            adUnitId = BANNER_AD_UNIT_ID
            setAdSize(AdSize.BANNER)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            adListener = object : AdListener() {
                override fun onAdLoaded() { visibility = View.VISIBLE }
                override fun onAdFailedToLoad(error: LoadAdError) { visibility = View.GONE }
            }
        }

        root.addView(webView)
        root.addView(offlineLayout)
        root.addView(bannerAdView)
        setContentView(root)

        // Load banner
        bannerAdView.loadAd(AdRequest.Builder().build())
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun WebView.configureWebView() {
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = false
            displayZoomControls = false
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            setSupportZoom(true)
            mediaPlaybackRequiresUserGesture = false
        }

        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                // Keep all navigation inside the WebView
                return false
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                // Schedule first interstitial after page loads
                if (INTERSTITIAL_INTERVAL_SECONDS > 0 && interstitialShownCount == 0) {
                    scheduleInterstitial(INTERSTITIAL_INTERVAL_SECONDS)
                }
            }

            override fun onReceivedError(
                view: WebView,
                errorCode: Int,
                description: String?,
                failingUrl: String?
            ) {
                super.onReceivedError(view, errorCode, description, failingUrl)
                if (!isOnline()) showOfflineScreen()
            }
        }

        webChromeClient = WebChromeClient()
    }

    // ── Offline screen ───────────────────────────────────────────

    private fun buildOfflineLayout(): LinearLayout {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
            setBackgroundColor(0xFF0F172A.toInt())
            visibility = View.GONE
        }

        offlineTitle = TextView(this).apply {
            text = "No Internet Connection"
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = android.view.Gravity.CENTER
            setPadding(40, 0, 40, 12)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

        offlineSubtitle = TextView(this).apply {
            text = "Please check your connection and try again."
            textSize = 14f
            setTextColor(0xFF94A3B8.toInt())
            gravity = android.view.Gravity.CENTER
            setPadding(48, 0, 48, 48)
        }

        retryButton = Button(this).apply {
            text = "Retry"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFFE2136E.toInt())
            setPadding(80, 28, 80, 28)
            setOnClickListener {
                if (isOnline()) {
                    showWebView()
                } else {
                    offlineSubtitle.text = "Still offline. Check your Wi-Fi or mobile data."
                }
            }
        }

        // Wifi icon emoji label
        val icon = TextView(this).apply {
            text = "📡"
            textSize = 64f
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }

        layout.addView(icon)
        layout.addView(offlineTitle)
        layout.addView(offlineSubtitle)
        layout.addView(retryButton)
        return layout
    }

    // ── Show / hide helpers ──────────────────────────────────────

    private fun showWebView() {
        offlineLayout.visibility = View.GONE
        webView.visibility = View.VISIBLE
        if (webView.url == null) {
            // Load local HTML from assets folder
            webView.loadUrl("file:///android_asset/index.html")
        }
    }

    private fun showOfflineScreen() {
        webView.visibility = View.GONE
        offlineLayout.visibility = View.VISIBLE
        offlineSubtitle.text = "Please check your connection and try again."
    }

    // ── Connectivity check ───────────────────────────────────────

    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
               capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    // ── Interstitial ad ──────────────────────────────────────────

    private fun loadInterstitialAd() {
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(
            this,
            INTERSTITIAL_AD_UNIT_ID,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            interstitialAd = null
                            loadInterstitialAd() // pre-load next one
                            if (INTERSTITIAL_INTERVAL_SECONDS > 0) {
                                scheduleInterstitial(INTERSTITIAL_INTERVAL_SECONDS)
                            }
                        }
                        override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                            interstitialAd = null
                            loadInterstitialAd()
                        }
                    }
                }
                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    interstitialAd = null
                }
            }
        )
    }

    fun showInterstitialAd(onDismissed: (() -> Unit)? = null) {
        val ad = interstitialAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    interstitialShownCount++
                    loadInterstitialAd()
                    onDismissed?.invoke()
                    if (INTERSTITIAL_INTERVAL_SECONDS > 0) {
                        scheduleInterstitial(INTERSTITIAL_INTERVAL_SECONDS)
                    }
                }
                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    interstitialAd = null
                    loadInterstitialAd()
                    onDismissed?.invoke()
                }
            }
            ad.show(this)
        } else {
            onDismissed?.invoke()
        }
    }

    private fun scheduleInterstitial(delaySeconds: Long) {
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({
            if (isOnline()) showInterstitialAd()
        }, delaySeconds * 1000)
    }
}
