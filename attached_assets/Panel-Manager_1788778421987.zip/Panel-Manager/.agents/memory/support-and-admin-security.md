---
name: Support and admin security
description: Durable product rules for human support escalation, reset approval, and admin access.
---

Human support must be the fallback for questions the assistant cannot answer confidently; unsupported questions should enter a visible queue rather than receive a guessed answer.

**Why:** Incorrect earning, withdrawal, or account guidance can cause user loss and cannot be safely corrected by a generic AI response.

**How to apply:** Keep queue states explicit (waiting, active, resolved), show the user their waiting state, and let an authenticated admin claim and close requests.

Admin APIs must accept only short-lived tokens issued by a successful admin login, not tokens that merely match a string prefix.

**Why:** Admin endpoints expose account and payment-related data, so a predictable or prefix-only token is an authorization bypass.

**How to apply:** Preserve server-side token validation whenever adding or changing admin endpoints; do not treat client-stored token shape as proof of identity.
