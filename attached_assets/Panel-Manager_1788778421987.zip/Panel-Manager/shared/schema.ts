import { sql } from "drizzle-orm";
import { pgTable, text, varchar, serial, decimal, boolean, timestamp, date, integer } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  password: text("password").notNull(),
  referralCode: varchar("referral_code", { length: 100 }).notNull().unique(),
  referredBy: varchar("referred_by", { length: 100 }),
  deviceId: varchar("device_id", { length: 255 }),
  balance: decimal("balance", { precision: 10, scale: 2 }).default("0"),
  totalEarned: decimal("total_earned", { precision: 10, scale: 2 }).default("0"),
  isActive: boolean("is_active").default(true),
  isBanned: boolean("is_banned").default(false),
  createdAt: timestamp("created_at").default(sql`NOW()`),
  lastLogin: timestamp("last_login").default(sql`NOW()`),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  type: varchar("type", { length: 50 }).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  description: text("description"),
  source: varchar("source", { length: 50 }),
  createdAt: timestamp("created_at").default(sql`NOW()`),
});

export const withdrawals = pgTable("withdrawals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  charge: decimal("charge", { precision: 10, scale: 2 }).notNull(),
  netAmount: decimal("net_amount", { precision: 10, scale: 2 }).notNull(),
  simProvider: varchar("sim_provider", { length: 50 }).notNull(),
  phoneNumber: varchar("phone_number", { length: 20 }).notNull(),
  status: varchar("status", { length: 20 }).default("pending"),
  createdAt: timestamp("created_at").default(sql`NOW()`),
  processedAt: timestamp("processed_at"),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  url: text("url"),
  category: varchar("category", { length: 50 }),
  reward: decimal("reward", { precision: 10, scale: 2 }).notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").default(sql`NOW()`),
});

export const userTasks = pgTable("user_tasks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  taskId: integer("task_id").references(() => tasks.id),
  completedAt: timestamp("completed_at").default(sql`NOW()`),
});

export const dailyCheckins = pgTable("daily_checkins", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  checkinDate: date("checkin_date").default(sql`CURRENT_DATE`),
  reward: decimal("reward", { precision: 10, scale: 2 }).default("0.5"),
});

export const adWatches = pgTable("ad_watches", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  reward: decimal("reward", { precision: 10, scale: 2 }).notNull(),
  watchedAt: timestamp("watched_at").default(sql`NOW()`),
});

export const gamePlays = pgTable("game_plays", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  gameType: varchar("game_type", { length: 50 }).notNull(),
  reward: decimal("reward", { precision: 10, scale: 2 }).default("0"),
  playedAt: timestamp("played_at").default(sql`NOW()`),
});

export const referrals = pgTable("referrals", {
  id: serial("id").primaryKey(),
  referrerId: integer("referrer_id").references(() => users.id),
  referredId: integer("referred_id").references(() => users.id),
  level: integer("level").notNull(),
  commissionRate: decimal("commission_rate", { precision: 5, scale: 2 }).notNull(),
  totalEarned: decimal("total_earned", { precision: 10, scale: 2 }).default("0"),
  createdAt: timestamp("created_at").default(sql`NOW()`),
});

export const adminSettings = pgTable("admin_settings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").default(sql`NOW()`),
});

export const adminAuth = pgTable("admin_auth", {
  id: serial("id").primaryKey(),
  pin: varchar("pin", { length: 255 }).notNull(),
  updatedAt: timestamp("updated_at").default(sql`NOW()`),
});

export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  type: varchar("type", { length: 50 }).notNull(),
  reward: decimal("reward", { precision: 10, scale: 2 }).notNull(),
  isActive: boolean("is_active").default(true),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  createdAt: timestamp("created_at").default(sql`NOW()`),
});

export const userEvents = pgTable("user_events", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  eventId: integer("event_id").references(() => events.id),
  claimedAt: timestamp("claimed_at").default(sql`NOW()`),
});

export type User = typeof users.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type Withdrawal = typeof withdrawals.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type UserTask = typeof userTasks.$inferSelect;
export type DailyCheckin = typeof dailyCheckins.$inferSelect;
export type AdWatch = typeof adWatches.$inferSelect;
export type GamePlay = typeof gamePlays.$inferSelect;
export type Referral = typeof referrals.$inferSelect;
export type AdminSetting = typeof adminSettings.$inferSelect;
export type Event = typeof events.$inferSelect;
