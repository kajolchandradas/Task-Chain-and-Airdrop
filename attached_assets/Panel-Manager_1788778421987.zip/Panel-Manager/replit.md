# Earn Wallet — Bangladesh TK Earning App

## Project Overview
A Bangladesh-themed Expo React Native mobile earning app where users earn TK by watching ads, playing 5 mini-games, and completing daily tasks. Features a 3-level referral system, multiple withdrawal methods, a leaderboard, special events, and a full admin panel with complete ad monetization management.

## Architecture

### Frontend (Expo / React Native)
- **Framework**: Expo SDK 54, React Native, Expo Router (file-based routing)
- **State Management**: React Query (server state), React Context (auth + ad state), useState (local state)
- **UI**: Poppins font, bKash-inspired pink theme (#E2136E primary), LinearGradient headers, card-based layouts
- **Font**: `@expo-google-fonts/poppins` (Regular, Medium, SemiBold, Bold)

### Backend (Express + TypeScript)
- **Server**: Express.js with TypeScript (`tsx` runner)
- **Database**: PostgreSQL via Drizzle ORM
- **Port**: 5000

## Key Files
- `app/_layout.tsx` — Root layout with fonts, AuthProvider, AdProvider, QueryClient, global touch capture
- `app/(tabs)/_layout.tsx` — Tab navigation (Home, Earn, Games, Wallet, Profile)
- `app/(tabs)/index.tsx` — Home dashboard (balance, check-in, events, quick actions)
- `app/(tabs)/earn.tsx` — Watch ads + daily tasks (hooked to AdContext)
- `app/(tabs)/games.tsx` — 5 game cards
- `app/(tabs)/wallet.tsx` — Withdraw funds, history, leaderboard
- `app/(tabs)/profile.tsx` — Referral tree, income breakdown, logout
- `app/game/[type].tsx` — Dynamic game screen (shows ad on open via AdContext)
- `app/(auth)/login.tsx` — User login
- `app/(auth)/register.tsx` — User registration with referral code
- `app/admin/index.tsx` — Admin PIN login (default: 1234)
- `app/admin/panel.tsx` — Full admin panel (dark theme, 7 tabs)
- `context/AuthContext.tsx` — Auth state management
- `context/AdContext.tsx` — Global ad state: settings, showAd(), trigger management
- `components/AdModal.tsx` — Full-screen ad overlay with countdown, zone ID, network branding
- `constants/colors.ts` — Theme colors (primary, success, danger, dark)
- `lib/query-client.ts` — React Query client + API utilities
- `server/routes.ts` — All API endpoints
- `server/storage.ts` — Database queries (Drizzle ORM)
- `shared/schema.ts` — Database schema (13 tables)

## Ad Monetization System
### Triggers (each toggle-able in admin)
- **On Any Click/Touch**: Global touch capture in root layout, with configurable cooldown
- **On Claim**: Shows ad before rewards for tasks/events/check-in are given
- **On Game Open**: Shows interstitial when user opens any game
- **On Watch Ads & Earn**: Shows rewarded video before ad reward is credited
- **On Check-in**: Ad before daily bonus
- **On Event Claim**: Ad before event reward
- **On Withdrawal Submit**: Ad before withdrawal processing

### Ad Configuration (admin "Ads" tab)
- Master switch (all ads on/off)
- Ad network selection: Monetag, AdSense, Unity, IronSource, AppLovin, Meta Audience
- Zone IDs per placement: default, interstitial, rewarded, game, claim, click, native
- Ad duration (seconds before skip button appears)
- Click cooldown (minimum seconds between click-triggered ads)
- Max ads per session
- Live preview of config status

### AdModal Features
- Full-screen modal with countdown timer + progress bar
- Loading phase (1.2s) then showing phase
- Simulated branded ad content (random Bangladesh brands)
- Zone ID watermark displayed
- Close button only appears after countdown completes
- Platform-aware animations (no native driver on web)

## Features
- **Earning**: Watch ads (up to 10/day), 5 games, daily check-in, task completion
- **Referrals**: 3-level system — L1: 10%, L2: 5%, L3: 2.5% commission
- **Withdrawals**: Teletalk, Grameen, Robi, Banglalink; 10% charge; min 50 TK
- **Leaderboard**: Top Earners, Top Referrers, Top Gamers
- **Events**: Special events with claim rewards

## Admin Panel (7 tabs, dark theme)
1. **Dashboard** — Stats + master ad switch + quick trigger toggles + earnings config
2. **Ads** — Full ad monetization: network, zone IDs, timing, triggers, live preview
3. **Tasks** — Add/delete tasks with category/reward
4. **Withdrawals** — Approve/reject requests (pending/approved/rejected tabs)
5. **Users** — View all users, ban/unban
6. **Settings** — Rewards, withdrawals, referral rates, PIN change
7. **Security** — 9 security toggles

## API Auth
- **User endpoints**: `x-user-id: <userId>` header
- **Admin endpoints**: `x-admin-token: <token>` header

## Colors
- Primary: `#E2136E` (bKash pink)
- Success: `#10b981`
- Warning: `#f59e0b`
- Danger: `#ef4444`
- Dark BG: `#0f172a`
- Dark Card: `#1e293b`

## Workflows
- **Start Backend**: `npm run server:dev` — Express on port 5000
- **Start Frontend**: `npm run expo:dev` — Expo dev server on port 8081

## Default Admin PIN: `1234`
